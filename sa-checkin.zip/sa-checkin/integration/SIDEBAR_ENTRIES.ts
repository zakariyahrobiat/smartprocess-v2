/**
 * SA Check-In sidebar entries for SmartProcess app-shell.
 *
 * ADD these objects into your existing sidebar nav config in:
 *   src/components/smart-process/app-shell.tsx  (or sidebar-nav.tsx)
 *
 * Pattern matches the existing IMS nav items.
 * ─────────────────────────────────────────────────────────────────
 */

export const SA_NAV_ITEMS = [
  // ── SA-Assistant ────────────────────────────────────────────────
  {
    label: 'My Check-In',
    icon: 'Fingerprint',           // lucide-react icon name
    path: '/sa/assistant',
    requiredPermission: 'sa:checkin',
    group: 'Shop Assistant',
  },

  // ── SA-Supervisor ───────────────────────────────────────────────
  {
    label: 'Team Attendance',
    icon: 'Users',
    path: '/sa/supervisor',
    requiredPermission: 'sa:supervisor',
    group: 'Shop Assistant',
  },

  // ── SA-HR ───────────────────────────────────────────────────────
  {
    label: 'SA — HR Portal',
    icon: 'ClipboardCheck',
    path: '/sa/hr',
    requiredPermission: 'sa:hr',
    group: 'Shop Assistant',
  },
]

/**
 * ADD these routes inside your <Routes> block in App.tsx or AppShell.tsx:
 *
 * import AssistantPortal   from '@/components/shop-assistant/AssistantPortal'
 * import SupervisorPortal  from '@/components/shop-assistant/SupervisorPortal'
 * import HRPortal          from '@/components/shop-assistant/HRPortal'
 *
 * <Route path="/sa/assistant"  element={<PermissionGuard permission="sa:checkin"><AssistantPortal /></PermissionGuard>} />
 * <Route path="/sa/supervisor" element={<PermissionGuard permission="sa:supervisor"><SupervisorPortal /></PermissionGuard>} />
 * <Route path="/sa/hr"         element={<PermissionGuard permission="sa:hr"><HRPortal /></PermissionGuard>} />
 *
 * ─────────────────────────────────────────────────────────────────
 * PermissionGuard pattern (if not already in codebase):
 * ─────────────────────────────────────────────────────────────────
 *
 * function PermissionGuard({ permission, children }: { permission: string; children: React.ReactNode }) {
 *   const { can } = usePermissions()
 *   if (!can(permission)) return <Navigate to="/" replace />
 *   return <>{children}</>
 * }
 */
