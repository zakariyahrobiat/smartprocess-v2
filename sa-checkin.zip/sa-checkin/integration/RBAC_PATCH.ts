/**
 * SA Check-In RBAC extension for SmartProcess v2.
 *
 * ADD these permission keys to your existing src/lib/rbac.ts permissions map.
 * The role assignments match the IMS RBAC pattern already in the codebase.
 *
 * ─────────────────────────────────────────────────────────────────
 * STEP 1: Add to your Permission type union in rbac.ts:
 * ─────────────────────────────────────────────────────────────────
 *
 *   | 'sa:checkin'           // SA-Assistant: can check in
 *   | 'sa:enroll'            // SA-Assistant: can enrol face
 *   | 'sa:view_history'      // SA-Assistant: can view own history
 *   | 'sa:supervisor'        // SA-Supervisor: team portal access
 *   | 'sa:override'          // SA-Supervisor: can issue overrides
 *   | 'sa:validate'          // SA-Supervisor: can validate monthly
 *   | 'sa:hr'                // SA-HR: full HR portal access
 *   | 'sa:hr_decisions'      // SA-HR: can approve/reject/export
 *
 * ─────────────────────────────────────────────────────────────────
 * STEP 2: Add to your rolePermissions map in rbac.ts:
 * ─────────────────────────────────────────────────────────────────
 *
 *   'SA-Assistant': [
 *     'sa:checkin',
 *     'sa:enroll',
 *     'sa:view_history',
 *   ],
 *   'SA-Supervisor': [
 *     'sa:checkin',          // supervisors can check in too
 *     'sa:enroll',
 *     'sa:view_history',
 *     'sa:supervisor',
 *     'sa:override',
 *     'sa:validate',
 *   ],
 *   'SA-HR': [
 *     'sa:hr',
 *     'sa:hr_decisions',
 *   ],
 *
 * ─────────────────────────────────────────────────────────────────
 * STEP 3: Add SA roles to your Firestore user documents:
 * ─────────────────────────────────────────────────────────────────
 *
 *   Field: roles (array)
 *   Values: 'SA-Assistant' | 'SA-Supervisor' | 'SA-HR'
 *
 *   These are independent of IMS roles. A user can hold both e.g.:
 *   roles: ['SA-Supervisor', 'IMS-LineManager']
 */

// ── Typed permission hook (copy into src/hooks/usePermissions.ts if not exists) ──

import { useAuth } from '../context/auth-provider'
import { hasPermission } from '../lib/rbac'

export function usePermissions() {
  const { userProfile } = useAuth()
  const roles: string[] = userProfile?.roles ?? []

  return {
    can: (permission: string) => hasPermission(roles, permission),
    isSAAssistant: roles.includes('SA-Assistant'),
    isSASupervisor: roles.includes('SA-Supervisor'),
    isSAHR: roles.includes('SA-HR'),
  }
}
