# SA Check-In — Integration Guide
## SmartProcess v2 · FastAPI + React + Firebase + Rekognition

---

## 1. Prerequisites

| Dependency | Status | Notes |
|---|---|---|
| SmartProcess v2 Codespace | ✅ Live | `legendary-garbanzo-jr9959xgxxvc4rp` |
| Firebase project | ✅ Exists | Already used by IMS |
| Google Sheets spreadsheet | ✅ Exists | Same spreadsheet as IMS |
| AWS account | ⏳ Pending | Need IAM user + Rekognition access |
| Cloud Run (FastAPI) | ⏳ Pending | Deploy after AWS creds confirmed |

---

## 2. Google Sheets Setup

1. Open the SmartProcess spreadsheet
2. Create the 8 sheets from `SHEETS_SCHEMA.md` with exact headers
3. Seed `[DB] Shops` with shop locations (Shop ID, lat, lng)
4. Seed `[DB] Assistants` with assistant emails and assigned shop IDs
5. Seed `[DB] HR` with HR user emails

---

## 3. Firebase Setup

### Storage Rules
Apply `integration/storage.rules` to your Firebase Storage.
Path: Firebase Console → Storage → Rules → paste and publish.

### Service Account
1. Firebase Console → Project Settings → Service Accounts → Generate new private key
2. Base64 encode it: `base64 -w 0 serviceAccount.json`
3. Add to backend `.env` as `FIREBASE_SERVICE_ACCOUNT_JSON`

---

## 4. AWS Rekognition Setup

1. AWS Console → IAM → Create user `smartprocess-rekognition`
2. Attach inline policy (least privilege):
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["rekognition:CompareFaces"],
    "Resource": "*"
  }]
}
```
3. Generate Access Key → add to backend `.env`

---

## 5. Backend Deployment (Cloud Run)

```bash
# From backend/ directory
gcloud builds submit --tag gcr.io/YOUR_PROJECT/smartprocess-sa-api
gcloud run deploy smartprocess-sa-api \
  --image gcr.io/YOUR_PROJECT/smartprocess-sa-api \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars "GOOGLE_SHEETS_SPREADSHEET_ID=xxx,AWS_REGION=us-east-1,..."
```

Add all `.env` vars as Cloud Run env vars (not in Docker image).

---

## 6. Frontend Integration (SmartProcess v2)

### Step 1 — Copy files into Codespace
```
src/
  api/saApi.ts                                    ← copy
  hooks/useCamera.ts                              ← copy
  types/sa.types.ts                               ← copy
  components/shop-assistant/
    AssistantPortal.tsx                           ← copy
    SupervisorPortal.tsx                          ← copy
    HRPortal.tsx                                  ← copy
```

### Step 2 — Add env variable
In `.env.local`:
```
VITE_API_BASE_URL=https://YOUR_CLOUD_RUN_URL.run.app
```

### Step 3 — Patch RBAC
Follow `integration/RBAC_PATCH.ts` — add SA permissions and role mappings to `src/lib/rbac.ts`.

### Step 4 — Add routes to App.tsx
Follow `integration/SIDEBAR_ENTRIES.ts` — add 3 routes and import the 3 components.

### Step 5 — Add sidebar entries
Follow `integration/SIDEBAR_ENTRIES.ts` — add `SA_NAV_ITEMS` to your sidebar nav config.

---

## 7. Running Tests

### Backend
```bash
cd backend
pip install -r requirements.txt
pytest -v
# Expected: 40+ tests, all green
```

### Frontend
```bash
cd frontend
npm install
npm run test:run
# Expected: 30+ tests, all green
```

---

## 8. AWS Credentials — Rollout Gate

**SA Face Check-In will NOT go live until AWS creds are confirmed.**

The FastAPI endpoints exist and are tested. The React components are wired.
The only blocker is `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` in the Cloud Run env.

Rekognition fallback: if AWS creds are missing or Rekognition fails, the
`/sa/checkin` endpoint returns `can_request_override: true` — supervisor
override remains the fallback path for the first few weeks.

---

## 9. Test Accounts for UAT

Seed these emails in the relevant sheets before UAT:

| Role | Email | Sheet |
|---|---|---|
| SA-Assistant | test.assistant@sunking.com | [DB] Assistants |
| SA-Supervisor | test.supervisor@sunking.com | [DB] Assistants → Supervisor Email |
| SA-HR | test.hr@sunking.com | [DB] HR |

Create matching Firebase Auth accounts via Firebase Console → Authentication → Add user.
Assign roles in Firestore: `users/{uid} → roles: ['SA-Assistant']`

---

## 10. Go-Live Checklist

- [ ] 8 Sheets created with correct headers
- [ ] [DB] Shops seeded with real shop coordinates
- [ ] [DB] Assistants seeded with all field staff emails
- [ ] Firebase Storage rules deployed
- [ ] AWS IAM user created, Rekognition policy attached
- [ ] Backend deployed to Cloud Run with all env vars
- [ ] `VITE_API_BASE_URL` set in Codespace `.env.local`
- [ ] RBAC patch applied to `rbac.ts`
- [ ] 3 routes added to `App.tsx`
- [ ] 3 sidebar entries added
- [ ] Backend tests passing: `pytest -v`
- [ ] Frontend tests passing: `npm run test:run`
- [ ] UAT completed with test accounts
- [ ] First enrollment approved via HR portal
- [ ] First face check-in verified end-to-end
