# SA Check-In — Google Sheets Schema
# Create these sheets in the SmartProcess Google Spreadsheet.
# Column order is exact — FastAPI reads by header name (case-insensitive), not position.
# But keeping order consistent avoids append_row misalignment bugs.

## [DB] Shops
| Shop ID | Shop Name | Lat | Lng | Region |

## [DB] Assistants
| Assistant Email | Assistant Name | Shop ID | ShopArea | Assistant ID | Supervisor Email | Enrollment Status | Reference Photo URL | Bank Name | Account Number |

# Enrollment Status values: NONE | PENDING | ENROLLED | REJECTED

## [DB] HR
| HR Email | HR Name |

## [LOG] Checkins
| TimeStamp | AssistantEmail | AssistantID | AssistantName | ShopID | ShopArea | Lat | Lng | Distance (m) | WithinRadius | Status | Comment | FaceMatchScore | FaceMatchStatus | CheckinMethod |

# Status values: Valid | Out of Range
# CheckinMethod values: FACE+GPS | SUPERVISOR_OVERRIDE

## [LOG] Enrollment Requests
| AssistantID | AssistantEmail | AssistantName | PhotoURL | DriveFileID | Status | RequestDate | ReviewedBy | ReviewDate | Comment |

# Status values: PENDING | APPROVED | REJECTED

## [LOG] Supervisor Overrides
| AssistantID | AssistantEmail | Month | Year | OverrideCount | SupervisorEmail | LastOverrideDate |

## [LOG] Monthly Validations
| AssistantID | AssistantEmail | ShopArea | Month | Year | CheckIns | WorkingDays | Percentage | SupervisorEmail | Status | ValidationDate | Comment |

# Status values: APPROVED | REJECTED

## [LOG] HR Decisions
| AssistantID | AssistantEmail | Month | Year | Decision | Comment | HREmail | DecisionDate |

# Decision values: VALIDATED | INELIGIBLE | PENDING_REVIEW
