from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.sa_routes import router as sa_router

app = FastAPI(
    title="SmartProcess API — SA Check-In",
    version="2.0.0",
    description="Shop Assistant Face Check-In: enrollment, GPS+face check-in, supervisor portal, HR portal.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Lock down to your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(sa_router)


@app.get("/health")
def health():
    return {"status": "ok"}
