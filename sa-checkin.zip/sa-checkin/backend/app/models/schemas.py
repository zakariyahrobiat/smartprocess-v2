from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, EmailStr, field_validator


# ── Enums ─────────────────────────────────────────────────────────────────────

class EnrollmentStatus(str, Enum):
    NONE = "NONE"
    PENDING = "PENDING"
    ENROLLED = "ENROLLED"
    REJECTED = "REJECTED"


class CheckinMethod(str, Enum):
    FACE_GPS = "FACE+GPS"
    SUPERVISOR_OVERRIDE = "SUPERVISOR_OVERRIDE"


class CheckinStatus(str, Enum):
    VALID = "Valid"
    OUT_OF_RANGE = "Out of Range"


class ValidationStatus(str, Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    PENDING = "PENDING"


class HRDecision(str, Enum):
    VALIDATED = "VALIDATED"
    INELIGIBLE = "INELIGIBLE"
    PENDING_REVIEW = "PENDING_REVIEW"


# ── Assistant ─────────────────────────────────────────────────────────────────

class AssistantProfile(BaseModel):
    assistant_id: str
    assistant_name: str
    email: str
    shop_id: str
    shop_area: str
    supervisor_email: str
    enrollment_status: EnrollmentStatus
    reference_photo_url: Optional[str] = None


class AssistantDashboard(BaseModel):
    profile: AssistantProfile
    checked_in_today: bool
    last_checkin_time: Optional[str] = None


# ── Enrollment ────────────────────────────────────────────────────────────────

class EnrollmentSubmitRequest(BaseModel):
    """Frontend sends the selfie as a base64 JPEG string."""
    face_image_base64: str
    firebase_storage_url: str  # URL already uploaded by React to Firebase Storage


class EnrollmentSubmitResponse(BaseModel):
    ok: bool
    message: str
    status: EnrollmentStatus


class EnrollmentRequest(BaseModel):
    assistant_id: str
    assistant_name: str
    email: str
    photo_url: str
    request_date: str


class EnrollmentDecisionRequest(BaseModel):
    assistant_id: str
    comment: Optional[str] = ""


class EnrollmentDecisionResponse(BaseModel):
    ok: bool
    message: str


# ── Check-in ──────────────────────────────────────────────────────────────────

class CheckinRequest(BaseModel):
    lat: float
    lng: float
    comment: Optional[str] = ""
    face_image_base64: str  # base64 JPEG captured from camera

    @field_validator("lat")
    @classmethod
    def validate_lat(cls, v: float) -> float:
        if not -90 <= v <= 90:
            raise ValueError("Latitude must be between -90 and 90")
        return v

    @field_validator("lng")
    @classmethod
    def validate_lng(cls, v: float) -> float:
        if not -180 <= v <= 180:
            raise ValueError("Longitude must be between -180 and 180")
        return v


class CheckinResponse(BaseModel):
    success: bool
    within_radius: Optional[bool]
    face_match_score: Optional[int] = None
    face_match_status: Optional[str] = None
    checkin_method: Optional[CheckinMethod] = None
    message: str
    can_request_override: bool = False
    enrollment_required: bool = False
    enrollment_status: Optional[EnrollmentStatus] = None


# ── Supervisor Override ───────────────────────────────────────────────────────

class OverrideRequest(BaseModel):
    assistant_id: str
    assistant_email: str
    comment: Optional[str] = ""


class OverrideResponse(BaseModel):
    ok: bool
    overrides_used: int
    overrides_remaining: int
    max_overrides: int
    message: str


class OverrideCountResponse(BaseModel):
    assistant_id: str
    count: int
    remaining: int
    max_overrides: int
    month: int
    year: int


# ── Supervisor Portal ─────────────────────────────────────────────────────────

class AssistantAttendanceSummary(BaseModel):
    assistant_id: str
    assistant_name: str
    assistant_email: str
    shop_id: str
    shop_area: str
    checkins: int
    working_days: int
    percentage: str
    passed: bool  # >= 70%
    validation_status: ValidationStatus
    validation_comment: Optional[str] = ""
    validation_date: Optional[str] = None


class SupervisorAssistantsResponse(BaseModel):
    month: int
    year: int
    working_days: int
    assistants: list[AssistantAttendanceSummary]


class ValidationRequest(BaseModel):
    assistant_id: str
    month: int
    year: int
    status: ValidationStatus
    comment: Optional[str] = ""


class ValidationResponse(BaseModel):
    ok: bool
    message: str


# ── HR Portal ─────────────────────────────────────────────────────────────────

class HROverviewRow(BaseModel):
    assistant_id: str
    assistant_name: str
    assistant_email: str
    shop_id: str
    shop_area: str
    supervisor_email: str
    checkins: int
    working_days: int
    percentage: str
    passed: bool
    supervisor_status: str
    supervisor_comment: Optional[str] = ""
    hr_status: HRDecision
    hr_comment: Optional[str] = ""
    enrollment_status: EnrollmentStatus


class HROverviewResponse(BaseModel):
    month: int
    year: int
    working_days: int
    rows: list[HROverviewRow]


class HRDecisionRequest(BaseModel):
    assistant_id: str
    month: int
    year: int
    assistant_email: str
    decision: HRDecision
    comment: Optional[str] = ""


class HRDecisionResponse(BaseModel):
    ok: bool
    hr_status: HRDecision
    message: str


class ExportRow(BaseModel):
    assistant_id: str
    assistant_name: str
    assistant_email: str
    shop_area: str
    bank_name: Optional[str] = ""
    account_number: Optional[str] = ""
    amount: int = 50000


class ExportResponse(BaseModel):
    ok: bool
    count: int
    filename: str
    csv: str
    message: str
