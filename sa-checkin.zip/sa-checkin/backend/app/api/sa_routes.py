"""
SA Check-In API — all routes for Assistant, Supervisor, and HR portals.
Auth: Firebase ID token required on all endpoints.
"""
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status

from app.core.auth import get_current_user, require_email
from app.core.config import get_settings
from app.models.schemas import (
    AssistantDashboard, CheckinRequest, CheckinResponse,
    EnrollmentDecisionRequest, EnrollmentDecisionResponse,
    EnrollmentSubmitRequest, EnrollmentSubmitResponse, EnrollmentStatus,
    ExportResponse, HRDecisionRequest, HRDecisionResponse,
    HRDecision, HROverviewResponse, HROverviewRow,
    OverrideRequest, OverrideResponse, OverrideCountResponse,
    SupervisorAssistantsResponse, AssistantAttendanceSummary,
    ValidationRequest, ValidationResponse, ValidationStatus,
)
from app.services import sheets_service as db
from app.services.checkin_service import process_checkin, process_override

router = APIRouter(prefix="/sa", tags=["Shop Assistant"])


# ═══════════════════════════════════════════════════════════════════
# ASSISTANT PORTAL
# ═══════════════════════════════════════════════════════════════════

@router.get("/dashboard", response_model=AssistantDashboard)
def get_dashboard(email: str = Depends(require_email)):
    """Returns assistant profile + today's check-in status."""
    assistant = db.get_assistant_by_email(email)
    if not assistant:
        raise HTTPException(status_code=404, detail="No assistant profile found for this email.")

    checked_in = db.has_valid_checkin_today(assistant.assistant_id)
    checkins = db.get_monthly_valid_checkins(
        assistant.assistant_id,
        datetime.utcnow().month,
        datetime.utcnow().year,
    )
    last_time = checkins[0]["timestamp_iso"] if checkins else None

    return AssistantDashboard(
        profile=assistant,
        checked_in_today=checked_in,
        last_checkin_time=last_time,
    )


@router.get("/checkins/history")
def get_checkin_history(
    month: int | None = None,
    year: int | None = None,
    email: str = Depends(require_email),
):
    """Returns this assistant's valid check-ins for a given month/year."""
    assistant = db.get_assistant_by_email(email)
    if not assistant:
        raise HTTPException(status_code=404, detail="Assistant not found.")

    now = datetime.utcnow()
    m = month or now.month
    y = year or now.year

    items = db.get_monthly_valid_checkins(assistant.assistant_id, m, y)
    return {"ok": True, "month": m, "year": y, "items": items}


@router.post("/checkin", response_model=CheckinResponse)
async def checkin(
    payload: CheckinRequest,
    email: str = Depends(require_email),
):
    """Face + GPS check-in."""
    assistant = db.get_assistant_by_email(email)
    if not assistant:
        raise HTTPException(status_code=404, detail="Assistant not found.")

    return await process_checkin(
        assistant=assistant,
        lat=payload.lat,
        lng=payload.lng,
        comment=payload.comment or "",
        face_image_base64=payload.face_image_base64,
    )


@router.post("/enroll", response_model=EnrollmentSubmitResponse)
def submit_enrollment(
    payload: EnrollmentSubmitRequest,
    email: str = Depends(require_email),
):
    """
    Assistant submits enrollment selfie.
    React has already uploaded the image to Firebase Storage and passes back the URL.
    """
    assistant = db.get_assistant_by_email(email)
    if not assistant:
        raise HTTPException(status_code=404, detail="Assistant not found.")

    if assistant.enrollment_status == EnrollmentStatus.ENROLLED:
        return EnrollmentSubmitResponse(
            ok=False,
            message="You are already enrolled. Contact HR to re-enrol.",
            status=EnrollmentStatus.ENROLLED,
        )
    if assistant.enrollment_status == EnrollmentStatus.PENDING:
        return EnrollmentSubmitResponse(
            ok=False,
            message="Your enrollment is pending HR approval.",
            status=EnrollmentStatus.PENDING,
        )

    db.log_enrollment_request(
        assistant=assistant,
        photo_url=payload.firebase_storage_url,
    )
    db.update_assistant_enrollment(
        assistant_id=assistant.assistant_id,
        status=EnrollmentStatus.PENDING,
    )

    return EnrollmentSubmitResponse(
        ok=True,
        message="Enrollment submitted. HR will review and activate your profile.",
        status=EnrollmentStatus.PENDING,
    )


# ═══════════════════════════════════════════════════════════════════
# SUPERVISOR PORTAL
# ═══════════════════════════════════════════════════════════════════

@router.get("/supervisor/assistants", response_model=SupervisorAssistantsResponse)
def get_supervisor_assistants(
    month: int | None = None,
    year: int | None = None,
    email: str = Depends(require_email),
):
    """Returns all assigned assistants with attendance summaries for the month."""
    now = datetime.utcnow()
    m = month or now.month
    y = year or now.year

    assistants = db.get_assistants_for_supervisor(email)
    if not assistants:
        raise HTTPException(status_code=404, detail="No assistants assigned to this supervisor.")

    working_days = db._working_days(m, y)
    checkin_counts = db.get_unique_valid_days_by_assistant(m, y)
    validation_map = db.get_validation_status_map(email, m, y)

    summaries = []
    for a in assistants:
        count = checkin_counts.get(a.assistant_id, 0)
        pct = round((count / working_days) * 100) if working_days else 0
        val = validation_map.get(a.assistant_id, {})

        summaries.append(AssistantAttendanceSummary(
            assistant_id=a.assistant_id,
            assistant_name=a.assistant_name,
            assistant_email=a.email,
            shop_id=a.shop_id,
            shop_area=a.shop_area,
            checkins=count,
            working_days=working_days,
            percentage=f"{pct}%",
            passed=pct >= 70,
            validation_status=ValidationStatus(
                str(val.get("status", "PENDING")).upper()
                if str(val.get("status", "PENDING")).upper() in ValidationStatus._value2member_map_
                else "PENDING"
            ),
            validation_comment=val.get("comment", ""),
            validation_date=val.get("validationdate"),
        ))

    return SupervisorAssistantsResponse(
        month=m, year=y, working_days=working_days, assistants=summaries
    )


@router.post("/supervisor/validate", response_model=ValidationResponse)
def validate_assistant(
    payload: ValidationRequest,
    email: str = Depends(require_email),
):
    """Supervisor approves or rejects an assistant's monthly attendance."""
    assistant = db.get_assistant_by_id(payload.assistant_id)
    if not assistant:
        raise HTTPException(status_code=404, detail="Assistant not found.")

    if assistant.supervisor_email.lower() != email.lower():
        raise HTTPException(
            status_code=403,
            detail="You are not the assigned supervisor for this assistant.",
        )

    working_days = db._working_days(payload.month, payload.year)
    checkin_counts = db.get_unique_valid_days_by_assistant(payload.month, payload.year)
    count = checkin_counts.get(assistant.assistant_id, 0)
    pct = round((count / working_days) * 100) if working_days else 0

    db.log_validation(
        assistant=assistant,
        checkins=count,
        working_days=working_days,
        percentage=f"{pct}%",
        supervisor_email=email,
        status=payload.status,
        comment=payload.comment or "",
        month=payload.month,
        year=payload.year,
    )

    return ValidationResponse(ok=True, message=f"Validation recorded: {payload.status.value}")


@router.post("/supervisor/override", response_model=CheckinResponse)
def supervisor_override(
    payload: OverrideRequest,
    email: str = Depends(require_email),
):
    """Supervisor issues a face-override check-in for a specific assistant."""
    assistant = db.get_assistant_by_id(payload.assistant_id)
    if not assistant:
        raise HTTPException(status_code=404, detail="Assistant not found.")

    # GPS not available server-side for override — use shop coords as stand-in
    try:
        shop_lat, shop_lng, _ = db.get_shop_coords(assistant.shop_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

    return process_override(
        assistant=assistant,
        supervisor_email=email,
        lat=shop_lat,
        lng=shop_lng,
        comment=payload.comment or "",
    )


@router.get("/supervisor/override-count/{assistant_id}", response_model=OverrideCountResponse)
def get_override_count(
    assistant_id: str,
    email: str = Depends(require_email),
):
    """Returns override usage for an assistant in the current month."""
    settings = get_settings()
    now = datetime.utcnow()
    count = db.get_override_count(assistant_id, now.month, now.year)
    return OverrideCountResponse(
        assistant_id=assistant_id,
        count=count,
        remaining=max(0, settings.sa_max_overrides - count),
        max_overrides=settings.sa_max_overrides,
        month=now.month,
        year=now.year,
    )


# ═══════════════════════════════════════════════════════════════════
# HR PORTAL
# ═══════════════════════════════════════════════════════════════════

def _require_hr(email: str = Depends(require_email)) -> str:
    if not db.is_hr_user(email):
        raise HTTPException(status_code=403, detail="HR access required.")
    return email


@router.get("/hr/enrollment-requests")
def get_enrollment_requests(hr_email: str = Depends(_require_hr)):
    """Returns all pending face enrollment requests."""
    items = db.get_pending_enrollments()
    return {"ok": True, "items": [i.model_dump() for i in items]}


@router.post("/hr/enrollment/{assistant_id}/approve", response_model=EnrollmentDecisionResponse)
def approve_enrollment(
    assistant_id: str,
    payload: EnrollmentDecisionRequest,
    hr_email: str = Depends(_require_hr),
):
    """HR approves a face enrollment — activates reference photo."""
    requests = db.get_pending_enrollments()
    pending = next((r for r in requests if r.assistant_id == assistant_id), None)
    if not pending:
        raise HTTPException(status_code=404, detail="No pending enrollment found.")

    db.update_enrollment_log(assistant_id, "APPROVED", hr_email, payload.comment or "")
    db.update_assistant_enrollment(
        assistant_id=assistant_id,
        status=EnrollmentStatus.ENROLLED,
        photo_url=pending.photo_url,
    )

    return EnrollmentDecisionResponse(ok=True, message="Enrollment approved.")


@router.post("/hr/enrollment/{assistant_id}/reject", response_model=EnrollmentDecisionResponse)
def reject_enrollment(
    assistant_id: str,
    payload: EnrollmentDecisionRequest,
    hr_email: str = Depends(_require_hr),
):
    """HR rejects a face enrollment."""
    db.update_enrollment_log(assistant_id, "REJECTED", hr_email, payload.comment or "")
    db.update_assistant_enrollment(
        assistant_id=assistant_id,
        status=EnrollmentStatus.REJECTED,
    )

    return EnrollmentDecisionResponse(ok=True, message="Enrollment rejected.")


@router.get("/hr/overview", response_model=HROverviewResponse)
def get_hr_overview(
    month: int | None = None,
    year: int | None = None,
    hr_email: str = Depends(_require_hr),
):
    """Full monthly overview for HR — all assistants, attendance, supervisor status, HR decisions."""
    now = datetime.utcnow()
    m = month or now.month
    y = year or now.year

    assistants = db.sheet_to_dicts(db.SHEETS.ASSISTANTS)
    working_days = db._working_days(m, y)
    checkin_counts = db.get_unique_valid_days_by_assistant(m, y)
    validation_map = db.get_all_validation_status_map(m, y)
    hr_decisions = db.get_hr_decisions_map(m, y)

    rows = []
    for a in assistants:
        aid = str(a.get("assistant id", "")).strip()
        if not aid:
            continue

        count = checkin_counts.get(aid, 0)
        pct = round((count / working_days) * 100) if working_days else 0
        val = validation_map.get(aid, {})
        hr = hr_decisions.get(aid, {})

        raw_status = str(a.get("enrollment status", "NONE")).upper()
        enrollment_status = EnrollmentStatus(raw_status) if raw_status in EnrollmentStatus._value2member_map_ else EnrollmentStatus.NONE

        raw_hr = str(hr.get("decision", "PENDING_REVIEW")).upper()
        hr_status = HRDecision(raw_hr) if raw_hr in HRDecision._value2member_map_ else HRDecision.PENDING_REVIEW

        rows.append(HROverviewRow(
            assistant_id=aid,
            assistant_name=a.get("assistant name", ""),
            assistant_email=a.get("assistant email", ""),
            shop_id=a.get("shop id", ""),
            shop_area=a.get("shoparea", ""),
            supervisor_email=a.get("supervisor email", ""),
            checkins=count,
            working_days=working_days,
            percentage=f"{pct}%",
            passed=pct >= 70,
            supervisor_status=str(val.get("status", "PENDING")),
            supervisor_comment=val.get("comment", ""),
            hr_status=hr_status,
            hr_comment=hr.get("comment", ""),
            enrollment_status=enrollment_status,
        ))

    return HROverviewResponse(month=m, year=y, working_days=working_days, rows=rows)


@router.post("/hr/decision", response_model=HRDecisionResponse)
def submit_hr_decision(
    payload: HRDecisionRequest,
    hr_email: str = Depends(_require_hr),
):
    """HR records a VALIDATED or INELIGIBLE decision for an assistant."""
    db.log_hr_decision(
        assistant_id=payload.assistant_id,
        assistant_email=payload.assistant_email,
        month=payload.month,
        year=payload.year,
        decision=payload.decision,
        comment=payload.comment or "",
        hr_email=hr_email,
    )
    return HRDecisionResponse(
        ok=True,
        hr_status=payload.decision,
        message=f"HR decision recorded: {payload.decision.value}",
    )


@router.get("/hr/export")
def export_approved(
    month: int | None = None,
    year: int | None = None,
    hr_email: str = Depends(_require_hr),
):
    """Generates CSV of all VALIDATED assistants with bank details + ₦50,000."""
    now = datetime.utcnow()
    m = month or now.month
    y = year or now.year

    csv_data, count = db.build_approved_csv(m, y)
    filename = f"Approved_SA_{y}_{m:02d}.csv"

    return ExportResponse(
        ok=True,
        count=count,
        filename=filename,
        csv=csv_data,
        message=f"{count} approved assistant(s) exported.",
    )
