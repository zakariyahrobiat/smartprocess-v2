"""
Core business logic for check-in, enrollment, and override.
All Sheets I/O is delegated to sheets_service.
Rekognition calls delegated to rekognition service.
"""
import httpx
import math
import logging
from datetime import datetime

from app.core.config import get_settings
from app.models.schemas import (
    CheckinResponse, CheckinMethod, EnrollmentStatus,
    OverrideResponse, AssistantProfile,
)
from app.services import sheets_service as db
from app.services.rekognition import compare_faces

logger = logging.getLogger(__name__)


# ── Haversine ─────────────────────────────────────────────────────────────────

def haversine_distance(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Returns distance in metres between two GPS coordinates."""
    R = 6_371_000
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lng2 - lng1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


# ── Check-in ──────────────────────────────────────────────────────────────────

async def process_checkin(
    assistant: AssistantProfile,
    lat: float,
    lng: float,
    comment: str,
    face_image_base64: str,
) -> CheckinResponse:
    settings = get_settings()

    # 1. Duplicate guard
    if db.has_valid_checkin_today(assistant.assistant_id):
        return CheckinResponse(
            success=False,
            within_radius=None,
            message="You already have a valid check-in today.",
        )

    # 2. GPS validation
    try:
        shop_lat, shop_lng, shop_name = db.get_shop_coords(assistant.shop_id)
    except ValueError as exc:
        return CheckinResponse(
            success=False, within_radius=None, message=str(exc)
        )

    distance = haversine_distance(shop_lat, shop_lng, lat, lng)
    within_radius = distance <= settings.sa_checkin_radius_m

    # 3. Enrollment gate
    if assistant.enrollment_status != EnrollmentStatus.ENROLLED or not assistant.reference_photo_url:
        return CheckinResponse(
            success=False,
            within_radius=within_radius,
            message=(
                "Your face enrollment is pending HR approval."
                if assistant.enrollment_status == EnrollmentStatus.PENDING
                else "Face enrollment required. Please enrol before checking in."
            ),
            enrollment_required=True,
            enrollment_status=assistant.enrollment_status,
        )

    # 4. Face validation
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(assistant.reference_photo_url)
            resp.raise_for_status()
            reference_bytes = resp.content
    except Exception as exc:
        logger.error("Failed to fetch reference photo: %s", exc)
        return CheckinResponse(
            success=False, within_radius=within_radius,
            message="Could not retrieve your enrolled face photo. Contact HR.",
        )

    face_result = compare_faces(reference_bytes, face_image_base64)
    face_passed = face_result.ok and face_result.similarity >= settings.sa_face_threshold

    if not face_passed:
        return CheckinResponse(
            success=False,
            within_radius=within_radius,
            face_match_score=face_result.similarity,
            face_match_status="No Match",
            message=(
                f"Face did not match ({face_result.similarity}% similarity, "
                f"minimum {settings.sa_face_threshold}%)."
                if face_result.ok
                else f"Face verification failed: {face_result.error}"
            ),
            can_request_override=True,
        )

    # 5. Log
    db.log_checkin(
        assistant=assistant,
        lat=lat, lng=lng,
        distance=distance,
        within_radius=within_radius,
        comment=comment,
        face_match_score=face_result.similarity,
        face_match_status="Match",
        checkin_method=CheckinMethod.FACE_GPS.value,
    )

    return CheckinResponse(
        success=True,
        within_radius=within_radius,
        face_match_score=face_result.similarity,
        face_match_status="Match",
        checkin_method=CheckinMethod.FACE_GPS,
        message=(
            f"Check-in recorded for {shop_name}. Face verified."
            if within_radius
            else f"Outside {settings.sa_checkin_radius_m}m of {shop_name}. Face verified."
        ),
    )


# ── Supervisor Override ───────────────────────────────────────────────────────

def process_override(
    assistant: AssistantProfile,
    supervisor_email: str,
    lat: float,
    lng: float,
    comment: str,
) -> CheckinResponse:
    settings = get_settings()

    # Verify supervisor assignment
    if assistant.supervisor_email.lower() != supervisor_email.lower():
        return CheckinResponse(
            success=False, within_radius=None,
            message="You are not the assigned supervisor for this assistant.",
        )

    # Duplicate guard
    if db.has_valid_checkin_today(assistant.assistant_id):
        return CheckinResponse(
            success=False, within_radius=None,
            message="This assistant already has a valid check-in today.",
        )

    now = datetime.utcnow()
    current_count = db.get_override_count(assistant.assistant_id, now.month, now.year)

    if current_count >= settings.sa_max_overrides:
        return CheckinResponse(
            success=False, within_radius=None,
            message=(
                f"Override limit reached. This assistant has used all "
                f"{settings.sa_max_overrides} overrides for {now.month}/{now.year}."
            ),
        )

    # GPS
    try:
        shop_lat, shop_lng, shop_name = db.get_shop_coords(assistant.shop_id)
    except ValueError as exc:
        return CheckinResponse(success=False, within_radius=None, message=str(exc))

    distance = haversine_distance(shop_lat, shop_lng, lat, lng)
    within_radius = distance <= settings.sa_checkin_radius_m

    new_count = db.record_override(
        assistant_id=assistant.assistant_id,
        assistant_email=assistant.email,
        supervisor_email=supervisor_email,
        month=now.month,
        year=now.year,
    )

    db.log_checkin(
        assistant=assistant,
        lat=lat, lng=lng,
        distance=distance,
        within_radius=within_radius,
        comment=comment,
        face_match_score=None,
        face_match_status="OVERRIDE",
        checkin_method=CheckinMethod.SUPERVISOR_OVERRIDE.value,
    )

    remaining = settings.sa_max_overrides - new_count
    return CheckinResponse(
        success=True,
        within_radius=within_radius,
        checkin_method=CheckinMethod.SUPERVISOR_OVERRIDE,
        message=(
            f"Override check-in recorded. {remaining} override(s) remaining this month."
        ),
    )
