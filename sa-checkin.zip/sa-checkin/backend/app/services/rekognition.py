import base64
import logging
from dataclasses import dataclass
from functools import lru_cache

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from app.core.config import get_settings

logger = logging.getLogger(__name__)


@dataclass
class FaceCompareResult:
    ok: bool
    similarity: int  # 0–100
    error: str = ""


@lru_cache
def _get_client():
    settings = get_settings()
    return boto3.client(
        "rekognition",
        aws_access_key_id=settings.aws_access_key_id,
        aws_secret_access_key=settings.aws_secret_access_key,
        region_name=settings.aws_region,
    )


def compare_faces(
    reference_image_bytes: bytes,
    live_image_base64: str,
    similarity_threshold: float = 50.0,  # fetch all above 50; we filter at SA_FACE_THRESHOLD
) -> FaceCompareResult:
    """
    Compares reference_image_bytes against live_image_base64 using Rekognition.

    Args:
        reference_image_bytes: raw bytes of the enrolled selfie (fetched from Firebase Storage)
        live_image_base64: base64-encoded JPEG from the React camera capture
        similarity_threshold: minimum score for Rekognition to include in FaceMatches

    Returns:
        FaceCompareResult with ok=True and similarity score (0–100),
        or ok=False with error message.
    """
    try:
        live_bytes = base64.b64decode(live_image_base64)

        response = _get_client().compare_faces(
            SourceImage={"Bytes": reference_image_bytes},
            TargetImage={"Bytes": live_bytes},
            SimilarityThreshold=similarity_threshold,
        )

        matches = response.get("FaceMatches", [])
        if not matches:
            return FaceCompareResult(ok=True, similarity=0)

        # Take highest similarity match
        top = max(matches, key=lambda m: m["Similarity"])
        return FaceCompareResult(ok=True, similarity=round(top["Similarity"]))

    except ClientError as exc:
        error_code = exc.response["Error"]["Code"]
        logger.error("Rekognition ClientError: %s", error_code, exc_info=True)
        return FaceCompareResult(ok=False, similarity=0, error=f"Rekognition error: {error_code}")

    except BotoCoreError as exc:
        logger.error("BotoCoreError: %s", exc, exc_info=True)
        return FaceCompareResult(ok=False, similarity=0, error=str(exc))

    except Exception as exc:
        logger.error("Unexpected face compare error: %s", exc, exc_info=True)
        return FaceCompareResult(ok=False, similarity=0, error=str(exc))
