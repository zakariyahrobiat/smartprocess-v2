"""
All Google Sheets read/write operations for the SA Check-In system.
Business logic lives in checkin_service.py — this layer is pure data access.
"""
import csv
import io
import logging
from datetime import datetime, date
from typing import Optional

from app.core.config import SHEETS, get_settings
from app.core.sheets import (
    append_row, find_row_index, sheet_to_dicts,
    update_cell, update_row_cells, read_sheet,
)
from app.models.schemas import (
    AssistantProfile, EnrollmentRequest, EnrollmentStatus,
    HRDecision, HROverviewRow, ValidationStatus,
)

logger = logging.getLogger(__name__)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _working_days(month: int, year: int) -> int:
    """Count Mon–Sat days in the given month/year (Sun = 0 days off)."""
    import calendar
    count = 0
    for day in range(1, calendar.monthrange(year, month)[1] + 1):
        if date(year, month, day).weekday() != 6:  # 6 = Sunday
            count += 1
    return count


def _today_bounds():
    now = datetime.utcnow()
    start = datetime(now.year, now.month, now.day)
    end = datetime(now.year, now.month, now.day + 1)
    return start, end


def _parse_dt(value) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value))
    except Exception:
        return None


# ── [DB] Assistants ───────────────────────────────────────────────────────────

def get_assistant_by_email(email: str) -> Optional[AssistantProfile]:
    rows = sheet_to_dicts(SHEETS.ASSISTANTS)
    for row in rows:
        if str(row.get("assistant email", "")).lower() == email.lower():
            return AssistantProfile(
                assistant_id=row.get("assistant id", ""),
                assistant_name=row.get("assistant name", ""),
                email=row.get("assistant email", ""),
                shop_id=row.get("shop id", ""),
                shop_area=row.get("shoparea", ""),
                supervisor_email=row.get("supervisor email", ""),
                enrollment_status=EnrollmentStatus(
                    str(row.get("enrollment status", "NONE")).upper()
                    if str(row.get("enrollment status", "NONE")).upper() in EnrollmentStatus._value2member_map_
                    else "NONE"
                ),
                reference_photo_url=row.get("reference photo url") or None,
            )
    return None


def get_assistant_by_id(assistant_id: str) -> Optional[AssistantProfile]:
    rows = sheet_to_dicts(SHEETS.ASSISTANTS)
    for row in rows:
        if str(row.get("assistant id", "")).strip() == assistant_id.strip():
            return AssistantProfile(
                assistant_id=row.get("assistant id", ""),
                assistant_name=row.get("assistant name", ""),
                email=row.get("assistant email", ""),
                shop_id=row.get("shop id", ""),
                shop_area=row.get("shoparea", ""),
                supervisor_email=row.get("supervisor email", ""),
                enrollment_status=EnrollmentStatus(
                    str(row.get("enrollment status", "NONE")).upper()
                    if str(row.get("enrollment status", "NONE")).upper() in EnrollmentStatus._value2member_map_
                    else "NONE"
                ),
                reference_photo_url=row.get("reference photo url") or None,
            )
    return None


def update_assistant_enrollment(
    assistant_id: str,
    status: EnrollmentStatus,
    photo_url: str = "",
) -> None:
    row_index = find_row_index(SHEETS.ASSISTANTS, "assistant id", assistant_id)
    if not row_index:
        raise ValueError(f"Assistant {assistant_id} not found in {SHEETS.ASSISTANTS}")

    rows = read_sheet(SHEETS.ASSISTANTS)
    header = [str(h).strip().lower() for h in rows[0]]

    updates = {}
    if "enrollment status" in header:
        updates[header.index("enrollment status") + 1] = status.value
    if "reference photo url" in header and photo_url:
        updates[header.index("reference photo url") + 1] = photo_url

    update_row_cells(SHEETS.ASSISTANTS, row_index, updates)


def get_assistants_for_supervisor(supervisor_email: str) -> list[AssistantProfile]:
    rows = sheet_to_dicts(SHEETS.ASSISTANTS)
    return [
        AssistantProfile(
            assistant_id=row.get("assistant id", ""),
            assistant_name=row.get("assistant name", ""),
            email=row.get("assistant email", ""),
            shop_id=row.get("shop id", ""),
            shop_area=row.get("shoparea", ""),
            supervisor_email=row.get("supervisor email", ""),
            enrollment_status=EnrollmentStatus(
                str(row.get("enrollment status", "NONE")).upper()
                if str(row.get("enrollment status", "NONE")).upper() in EnrollmentStatus._value2member_map_
                else "NONE"
            ),
            reference_photo_url=row.get("reference photo url") or None,
        )
        for row in rows
        if str(row.get("supervisor email", "")).lower() == supervisor_email.lower()
    ]


# ── [DB] Shops ────────────────────────────────────────────────────────────────

def get_shop_coords(shop_id: str) -> tuple[float, float, str]:
    """Returns (lat, lng, shop_name). Raises ValueError if not found."""
    rows = sheet_to_dicts(SHEETS.SHOPS)
    for row in rows:
        if str(row.get("shop id", "")).strip() == shop_id.strip():
            return (
                float(row.get("lat", 0)),
                float(row.get("lng", 0)),
                row.get("shop name", shop_id),
            )
    raise ValueError(f"Shop {shop_id} not found")


# ── [DB] HR ───────────────────────────────────────────────────────────────────

def is_hr_user(email: str) -> bool:
    rows = sheet_to_dicts(SHEETS.HR)
    return any(
        str(row.get("hr email", row.get(list(row.keys())[0], ""))).lower() == email.lower()
        for row in rows
    )


# ── [LOG] Checkins ────────────────────────────────────────────────────────────

def has_valid_checkin_today(assistant_id: str) -> bool:
    rows = sheet_to_dicts(SHEETS.CHECKINS)
    start, end = _today_bounds()
    for row in reversed(rows):
        if str(row.get("assistantid", "")).strip() != assistant_id.strip():
            continue
        ts = _parse_dt(row.get("timestamp", ""))
        if not ts:
            continue
        if start <= ts < end and str(row.get("status", "")) == "Valid":
            return True
    return False


def log_checkin(
    assistant: AssistantProfile,
    lat: float,
    lng: float,
    distance: float,
    within_radius: bool,
    comment: str,
    face_match_score: Optional[int],
    face_match_status: str,
    checkin_method: str,
) -> None:
    status = "Valid" if within_radius else "Out of Range"
    append_row(SHEETS.CHECKINS, [
        datetime.utcnow().isoformat(),
        assistant.email,
        assistant.assistant_id,
        assistant.assistant_name,
        assistant.shop_id,
        assistant.shop_area,
        lat,
        lng,
        round(distance, 2),
        within_radius,
        status,
        comment or "",
        face_match_score if face_match_score is not None else "",
        face_match_status,
        checkin_method,
    ])


def get_monthly_valid_checkins(assistant_id: str, month: int, year: int) -> list[dict]:
    rows = sheet_to_dicts(SHEETS.CHECKINS)
    results = []
    seen_days: set[str] = set()

    for row in reversed(rows):
        if str(row.get("assistantid", "")).strip() != assistant_id.strip():
            continue
        if str(row.get("status", "")) != "Valid":
            continue
        ts = _parse_dt(row.get("timestamp", ""))
        if not ts:
            continue
        if ts.month != month or ts.year != year:
            continue
        day_key = ts.strftime("%Y-%m-%d")
        if day_key in seen_days:
            continue
        seen_days.add(day_key)
        results.append({
            "timestamp_iso": ts.isoformat(),
            "assistant_id": row.get("assistantid", ""),
            "distance_m": row.get("distance (m)", ""),
            "within_radius": row.get("withinradius", ""),
            "comment": row.get("comment", ""),
            "face_match_score": row.get("facematchscore", ""),
            "checkin_method": row.get("checkinmethod", ""),
        })
        if len(results) >= 60:
            break

    return results


def get_unique_valid_days_by_assistant(month: int, year: int) -> dict[str, int]:
    """Returns {assistant_id: count_of_unique_valid_days} for a month/year."""
    rows = sheet_to_dicts(SHEETS.CHECKINS)
    day_sets: dict[str, set] = {}

    for row in rows:
        if str(row.get("status", "")) != "Valid":
            continue
        ts = _parse_dt(row.get("timestamp", ""))
        if not ts or ts.month != month or ts.year != year:
            continue
        aid = str(row.get("assistantid", "")).strip()
        if not aid:
            continue
        day_sets.setdefault(aid, set()).add(ts.strftime("%Y-%m-%d"))

    return {aid: len(days) for aid, days in day_sets.items()}


# ── [LOG] Enrollment Requests ─────────────────────────────────────────────────

def log_enrollment_request(
    assistant: AssistantProfile,
    photo_url: str,
    drive_file_id: str = "",
) -> None:
    append_row(SHEETS.ENROLLMENT_REQUESTS, [
        assistant.assistant_id,
        assistant.email,
        assistant.assistant_name,
        photo_url,
        drive_file_id,
        "PENDING",
        datetime.utcnow().isoformat(),
        "", "", "",  # ReviewedBy, ReviewDate, Comment
    ])


def get_pending_enrollments() -> list[EnrollmentRequest]:
    rows = sheet_to_dicts(SHEETS.ENROLLMENT_REQUESTS)
    return [
        EnrollmentRequest(
            assistant_id=row.get("assistantid", ""),
            assistant_name=row.get("assistantname", ""),
            email=row.get("assistantemail", ""),
            photo_url=row.get("photourl", ""),
            request_date=row.get("requestdate", ""),
        )
        for row in rows
        if str(row.get("status", "")).upper() == "PENDING"
    ]


def update_enrollment_log(
    assistant_id: str,
    decision: str,  # "APPROVED" or "REJECTED"
    reviewer_email: str,
    comment: str,
) -> None:
    rows = read_sheet(SHEETS.ENROLLMENT_REQUESTS)
    if not rows:
        return
    header = [str(h).strip().lower() for h in rows[0]]
    id_idx = header.index("assistantid") if "assistantid" in header else -1
    status_idx = header.index("status") if "status" in header else -1
    reviewer_idx = header.index("reviewedby") if "reviewedby" in header else -1
    review_date_idx = header.index("reviewdate") if "reviewdate" in header else -1
    comment_idx = header.index("comment") if "comment" in header else -1

    # Update last PENDING row for this assistant (bottom-up)
    for i in range(len(rows) - 1, 0, -1):
        row = rows[i]
        row_id = str(row[id_idx]).strip() if id_idx >= 0 and id_idx < len(row) else ""
        row_status = str(row[status_idx]).strip().upper() if status_idx >= 0 and status_idx < len(row) else ""
        if row_id == assistant_id.strip() and row_status == "PENDING":
            updates = {}
            if status_idx >= 0:
                updates[status_idx + 1] = decision
            if reviewer_idx >= 0:
                updates[reviewer_idx + 1] = reviewer_email
            if review_date_idx >= 0:
                updates[review_date_idx + 1] = datetime.utcnow().isoformat()
            if comment_idx >= 0:
                updates[comment_idx + 1] = comment
            update_row_cells(SHEETS.ENROLLMENT_REQUESTS, i + 1, updates)
            return


# ── [LOG] Supervisor Overrides ────────────────────────────────────────────────

def get_override_count(assistant_id: str, month: int, year: int) -> int:
    rows = sheet_to_dicts(SHEETS.SUPERVISOR_OVERRIDES)
    for row in rows:
        if (
            str(row.get("assistantid", "")).strip() == assistant_id.strip()
            and int(row.get("month", 0)) == month
            and int(row.get("year", 0)) == year
        ):
            return int(row.get("overridecount", 0))
    return 0


def record_override(
    assistant_id: str,
    assistant_email: str,
    supervisor_email: str,
    month: int,
    year: int,
) -> int:
    """Increments override count and returns new count."""
    rows = read_sheet(SHEETS.SUPERVISOR_OVERRIDES)
    if not rows:
        append_row(SHEETS.SUPERVISOR_OVERRIDES, [
            assistant_id, assistant_email, month, year, 1, supervisor_email,
            datetime.utcnow().isoformat(),
        ])
        return 1

    header = [str(h).strip().lower() for h in rows[0]]
    id_idx = header.index("assistantid") if "assistantid" in header else -1
    month_idx = header.index("month") if "month" in header else -1
    year_idx = header.index("year") if "year" in header else -1
    count_idx = header.index("overridecount") if "overridecount" in header else -1
    date_idx = header.index("lastoverridedate") if "lastoverridedate" in header else -1

    for i, row in enumerate(rows[1:], start=2):
        row_id = str(row[id_idx]).strip() if id_idx >= 0 and id_idx < len(row) else ""
        row_month = int(row[month_idx]) if month_idx >= 0 and month_idx < len(row) and row[month_idx] else 0
        row_year = int(row[year_idx]) if year_idx >= 0 and year_idx < len(row) and row[year_idx] else 0

        if row_id == assistant_id.strip() and row_month == month and row_year == year:
            new_count = int(row[count_idx]) + 1 if count_idx >= 0 and count_idx < len(row) else 1
            updates = {}
            if count_idx >= 0:
                updates[count_idx + 1] = new_count
            if date_idx >= 0:
                updates[date_idx + 1] = datetime.utcnow().isoformat()
            update_row_cells(SHEETS.SUPERVISOR_OVERRIDES, i, updates)
            return new_count

    # No existing row — create new
    append_row(SHEETS.SUPERVISOR_OVERRIDES, [
        assistant_id, assistant_email, month, year, 1, supervisor_email,
        datetime.utcnow().isoformat(),
    ])
    return 1


# ── [LOG] Monthly Validations ─────────────────────────────────────────────────

def log_validation(
    assistant: AssistantProfile,
    checkins: int,
    working_days: int,
    percentage: str,
    supervisor_email: str,
    status: ValidationStatus,
    comment: str,
    month: int,
    year: int,
) -> None:
    append_row(SHEETS.MONTHLY_VALIDATIONS, [
        assistant.assistant_id,
        assistant.email,
        assistant.shop_area,
        month,
        year,
        checkins,
        working_days,
        percentage,
        supervisor_email,
        status.value,
        datetime.utcnow().isoformat(),
        comment or "",
    ])


def get_validation_status_map(supervisor_email: str, month: int, year: int) -> dict[str, dict]:
    """Returns {assistant_id: latest_validation_row} for supervisor/month/year."""
    rows = sheet_to_dicts(SHEETS.MONTHLY_VALIDATIONS)
    result: dict[str, dict] = {}

    for row in rows:
        if str(row.get("supervisoremail", "")).lower() != supervisor_email.lower():
            continue
        if int(row.get("month", 0)) != month or int(row.get("year", 0)) != year:
            continue
        aid = str(row.get("assistantid", "")).strip()
        if not aid:
            continue
        ts = _parse_dt(row.get("validationdate", ""))
        prev = result.get(aid)
        if prev is None:
            result[aid] = {**row, "_ts": ts or datetime.min}
        else:
            if ts and ts > prev.get("_ts", datetime.min):
                result[aid] = {**row, "_ts": ts}

    for aid in result:
        result[aid].pop("_ts", None)

    return result


def get_all_validation_status_map(month: int, year: int) -> dict[str, dict]:
    """Returns {assistant_id: latest_validation_row} across all supervisors for HR view."""
    rows = sheet_to_dicts(SHEETS.MONTHLY_VALIDATIONS)
    result: dict[str, dict] = {}

    for row in rows:
        if int(row.get("month", 0)) != month or int(row.get("year", 0)) != year:
            continue
        aid = str(row.get("assistantid", "")).strip()
        if not aid:
            continue
        ts = _parse_dt(row.get("validationdate", ""))
        prev = result.get(aid)
        if prev is None:
            result[aid] = {**row, "_ts": ts or datetime.min}
        else:
            if ts and ts > prev.get("_ts", datetime.min):
                result[aid] = {**row, "_ts": ts}

    for aid in result:
        result[aid].pop("_ts", None)

    return result


# ── [LOG] HR Decisions ────────────────────────────────────────────────────────

def log_hr_decision(
    assistant_id: str,
    assistant_email: str,
    month: int,
    year: int,
    decision: HRDecision,
    comment: str,
    hr_email: str,
) -> None:
    append_row(SHEETS.HR_DECISIONS, [
        assistant_id,
        assistant_email,
        month,
        year,
        decision.value,
        comment or "",
        hr_email,
        datetime.utcnow().isoformat(),
    ])


def get_hr_decisions_map(month: int, year: int) -> dict[str, dict]:
    """Returns {assistant_id: latest_hr_decision} for month/year."""
    rows = sheet_to_dicts(SHEETS.HR_DECISIONS)
    result: dict[str, dict] = {}

    for row in rows:
        if int(row.get("month", 0)) != month or int(row.get("year", 0)) != year:
            continue
        aid = str(row.get("assistantid", "")).strip()
        if not aid:
            continue
        ts = _parse_dt(row.get("decisiondate", row.get("date", "")))
        prev = result.get(aid)
        if prev is None:
            result[aid] = {**row, "_ts": ts or datetime.min}
        else:
            if ts and ts > prev.get("_ts", datetime.min):
                result[aid] = {**row, "_ts": ts}

    for aid in result:
        result[aid].pop("_ts", None)

    return result


# ── Export ────────────────────────────────────────────────────────────────────

def build_approved_csv(month: int, year: int) -> tuple[str, int]:
    """
    Builds CSV of all VALIDATED assistants with bank details + ₦50,000.
    Returns (csv_string, count).
    """
    assistants = sheet_to_dicts(SHEETS.ASSISTANTS)
    hr_decisions = get_hr_decisions_map(month, year)

    validated_ids = {
        aid for aid, row in hr_decisions.items()
        if str(row.get("decision", "")).upper() == HRDecision.VALIDATED.value
    }

    assistant_map = {
        str(row.get("assistant id", "")).strip(): row
        for row in assistants
    }

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "AssistantID", "Name", "Email", "ShopArea",
        "BankName", "AccountNumber", "Amount", "Currency", "Month", "Year",
    ])

    count = 0
    for aid in validated_ids:
        row = assistant_map.get(aid)
        if not row:
            continue
        writer.writerow([
            aid,
            row.get("assistant name", ""),
            row.get("assistant email", ""),
            row.get("shoparea", ""),
            row.get("bank name", ""),
            row.get("account number", ""),
            50000,
            "NGN",
            month,
            year,
        ])
        count += 1

    return output.getvalue(), count
