from functools import lru_cache
from typing import Any

from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

from app.core.config import SHEETS, get_settings

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]


@lru_cache
def _get_service():
    settings = get_settings()
    creds = Credentials.from_service_account_info(
        settings.google_service_account_info, scopes=SCOPES
    )
    return build("sheets", "v4", credentials=creds, cache_discovery=False)


def _spreadsheet_id() -> str:
    return get_settings().google_sheets_spreadsheet_id


# ── Read ─────────────────────────────────────────────────────────────────────

def read_sheet(sheet_name: str) -> list[list[Any]]:
    """Returns all rows including header."""
    result = (
        _get_service()
        .spreadsheets()
        .values()
        .get(spreadsheetId=_spreadsheet_id(), range=sheet_name)
        .execute()
    )
    return result.get("values", [])


def sheet_to_dicts(sheet_name: str) -> list[dict]:
    """Returns list of dicts keyed by header row (lowercased, stripped)."""
    rows = read_sheet(sheet_name)
    if not rows:
        return []
    header = [str(h).strip().lower() for h in rows[0]]
    return [
        {header[i]: row[i] if i < len(row) else "" for i in range(len(header))}
        for row in rows[1:]
    ]


# ── Write ────────────────────────────────────────────────────────────────────

def append_row(sheet_name: str, values: list[Any]) -> None:
    """Appends a single row to the named sheet."""
    _get_service().spreadsheets().values().append(
        spreadsheetId=_spreadsheet_id(),
        range=sheet_name,
        valueInputOption="USER_ENTERED",
        insertDataOption="INSERT_ROWS",
        body={"values": [values]},
    ).execute()


def update_cell(sheet_name: str, row_index: int, col_index: int, value: Any) -> None:
    """
    Updates a single cell. row_index and col_index are 1-based
    (matching Sheets A1 notation: row 1 = header).
    """
    col_letter = _col_letter(col_index)
    cell_range = f"{sheet_name}!{col_letter}{row_index}"
    _get_service().spreadsheets().values().update(
        spreadsheetId=_spreadsheet_id(),
        range=cell_range,
        valueInputOption="USER_ENTERED",
        body={"values": [[value]]},
    ).execute()


def update_row_cells(sheet_name: str, row_index: int, col_updates: dict[int, Any]) -> None:
    """
    Updates multiple cells in one row. col_updates = {col_index_1based: value}.
    Makes one batchUpdate call to minimise API quota usage.
    """
    data = []
    for col_index, value in col_updates.items():
        col_letter = _col_letter(col_index)
        data.append({
            "range": f"{sheet_name}!{col_letter}{row_index}",
            "values": [[value]],
        })
    _get_service().spreadsheets().values().batchUpdate(
        spreadsheetId=_spreadsheet_id(),
        body={"valueInputOption": "USER_ENTERED", "data": data},
    ).execute()


# ── Helpers ──────────────────────────────────────────────────────────────────

def _col_letter(n: int) -> str:
    """Convert 1-based column index to A1 letter (e.g. 1→A, 27→AA)."""
    result = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        result = chr(65 + remainder) + result
    return result


def find_row_index(sheet_name: str, col_key: str, value: str) -> int | None:
    """
    Returns 1-based row index (including header) of the first row
    where the column matching col_key equals value (case-insensitive).
    Returns None if not found.
    """
    rows = read_sheet(sheet_name)
    if not rows:
        return None
    header = [str(h).strip().lower() for h in rows[0]]
    try:
        col_idx = header.index(col_key.lower())
    except ValueError:
        return None
    for i, row in enumerate(rows[1:], start=2):  # start=2: header is row 1
        cell = str(row[col_idx]).strip().lower() if col_idx < len(row) else ""
        if cell == value.strip().lower():
            return i
    return None
