import base64
import json
import os
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Google Sheets
    google_sheets_spreadsheet_id: str
    google_service_account_json: str  # base64-encoded service account JSON

    # AWS Rekognition
    aws_access_key_id: str
    aws_secret_access_key: str
    aws_region: str = "us-east-1"

    # Firebase
    firebase_project_id: str
    firebase_service_account_json: str  # base64-encoded

    # SA business rules
    sa_face_threshold: int = 80
    sa_max_overrides: int = 3
    sa_checkin_radius_m: int = 200

    class Config:
        env_file = ".env"

    @property
    def google_service_account_info(self) -> dict:
        return json.loads(base64.b64decode(self.google_service_account_json))

    @property
    def firebase_service_account_info(self) -> dict:
        return json.loads(base64.b64decode(self.firebase_service_account_json))


# Sheet names — single source of truth
class SheetNames:
    SHOPS = "[DB] Shops"
    ASSISTANTS = "[DB] Assistants"
    HR = "[DB] HR"
    CHECKINS = "[LOG] Checkins"
    ENROLLMENT_REQUESTS = "[LOG] Enrollment Requests"
    SUPERVISOR_OVERRIDES = "[LOG] Supervisor Overrides"
    MONTHLY_VALIDATIONS = "[LOG] Monthly Validations"
    HR_DECISIONS = "[LOG] HR Decisions"


SHEETS = SheetNames()


@lru_cache
def get_settings() -> Settings:
    return Settings()
