from functools import lru_cache
import firebase_admin
from firebase_admin import auth, credentials
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.config import get_settings

bearer = HTTPBearer()


@lru_cache
def _init_firebase():
    settings = get_settings()
    if not firebase_admin._apps:
        cred = credentials.Certificate(settings.firebase_service_account_info)
        firebase_admin.initialize_app(cred)


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(bearer),
) -> dict:
    """
    Verifies Firebase ID token from Authorization: Bearer <token> header.
    Returns decoded token dict with uid, email, etc.
    Raises 401 if invalid.
    """
    _init_firebase()
    try:
        decoded = auth.verify_id_token(credentials.credentials)
        return decoded
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid or expired token: {exc}",
        )


def require_email(current_user: dict = Depends(get_current_user)) -> str:
    """Extracts and returns email from verified token. Raises 401 if missing."""
    email = current_user.get("email")
    if not email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token does not contain email claim.",
        )
    return email
