"""
Tests for app/services/rekognition.py
TDD: these tests define the contract — compare_faces must satisfy all of them.
"""
import base64
import pytest
from unittest.mock import MagicMock, patch
from botocore.exceptions import ClientError

from app.services.rekognition import compare_faces, FaceCompareResult


DUMMY_REF_BYTES = b"\xff\xd8\xff\xe0" + b"\x00" * 100
DUMMY_LIVE_B64 = base64.b64encode(b"\xff\xd8\xff\xe0" + b"\x00" * 100).decode()


class TestCompareFaces:

    def test_returns_high_similarity_when_face_matches(self):
        """When Rekognition returns a match, similarity should be >= threshold."""
        mock_response = {
            "FaceMatches": [{"Similarity": 92.5, "Face": {}}],
            "UnmatchedFaces": [],
        }
        with patch("app.services.rekognition._get_client") as mock_client:
            mock_client.return_value.compare_faces.return_value = mock_response
            result = compare_faces(DUMMY_REF_BYTES, DUMMY_LIVE_B64)

        assert result.ok is True
        assert result.similarity == 93  # rounded
        assert result.error == ""

    def test_returns_zero_similarity_when_no_face_matches(self):
        """When Rekognition finds no matching face, similarity should be 0."""
        mock_response = {"FaceMatches": [], "UnmatchedFaces": [{"Face": {}}]}
        with patch("app.services.rekognition._get_client") as mock_client:
            mock_client.return_value.compare_faces.return_value = mock_response
            result = compare_faces(DUMMY_REF_BYTES, DUMMY_LIVE_B64)

        assert result.ok is True
        assert result.similarity == 0

    def test_picks_highest_similarity_when_multiple_matches(self):
        """When multiple faces match, the highest similarity wins."""
        mock_response = {
            "FaceMatches": [
                {"Similarity": 70.0, "Face": {}},
                {"Similarity": 95.0, "Face": {}},
                {"Similarity": 83.0, "Face": {}},
            ],
        }
        with patch("app.services.rekognition._get_client") as mock_client:
            mock_client.return_value.compare_faces.return_value = mock_response
            result = compare_faces(DUMMY_REF_BYTES, DUMMY_LIVE_B64)

        assert result.similarity == 95

    def test_returns_ok_false_on_client_error(self):
        """Rekognition API errors should return ok=False with error message."""
        error_response = {"Error": {"Code": "InvalidImageException", "Message": "Bad image"}}
        with patch("app.services.rekognition._get_client") as mock_client:
            mock_client.return_value.compare_faces.side_effect = ClientError(
                error_response, "CompareFaces"
            )
            result = compare_faces(DUMMY_REF_BYTES, DUMMY_LIVE_B64)

        assert result.ok is False
        assert result.similarity == 0
        assert "InvalidImageException" in result.error

    def test_returns_ok_false_on_unexpected_exception(self):
        """Unexpected errors should be caught and returned as ok=False."""
        with patch("app.services.rekognition._get_client") as mock_client:
            mock_client.return_value.compare_faces.side_effect = Exception("Network timeout")
            result = compare_faces(DUMMY_REF_BYTES, DUMMY_LIVE_B64)

        assert result.ok is False
        assert "Network timeout" in result.error

    def test_decodes_base64_live_image(self):
        """compare_faces must base64-decode the live image before sending to Rekognition."""
        raw_bytes = b"\xff\xd8\xff\xe0test_image_data"
        encoded = base64.b64encode(raw_bytes).decode()
        mock_response = {"FaceMatches": [{"Similarity": 88.0, "Face": {}}]}

        with patch("app.services.rekognition._get_client") as mock_client:
            mock_client.return_value.compare_faces.return_value = mock_response
            compare_faces(DUMMY_REF_BYTES, encoded)

            call_kwargs = mock_client.return_value.compare_faces.call_args
            target_bytes = call_kwargs.kwargs["TargetImage"]["Bytes"]
            assert target_bytes == raw_bytes
