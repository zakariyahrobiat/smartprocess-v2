"""
Tests for app/api/sa_routes.py
TDD: API contract tests — every endpoint has a test before it runs in prod.
All Sheets/Firebase/Rekognition calls mocked at the service boundary.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from app.models.schemas import (
    AssistantDashboard, EnrollmentStatus, EnrollmentRequest,
    CheckinResponse, CheckinMethod, HRDecision, ValidationStatus,
)


# ═══════════════════════════════════════════════════════════════════
# ASSISTANT PORTAL
# ═══════════════════════════════════════════════════════════════════

class TestGetDashboard:

    def test_returns_dashboard_for_known_assistant(self, client, auth_headers_assistant, enrolled_assistant):
        with (
            patch("app.api.sa_routes.db.get_assistant_by_email", return_value=enrolled_assistant),
            patch("app.api.sa_routes.db.has_valid_checkin_today", return_value=False),
            patch("app.api.sa_routes.db.get_monthly_valid_checkins", return_value=[]),
        ):
            resp = client.get("/sa/dashboard", headers=auth_headers_assistant)

        assert resp.status_code == 200
        data = resp.json()
        assert data["profile"]["assistant_id"] == "SKSA-0001"
        assert data["checked_in_today"] is False

    def test_returns_404_for_unknown_email(self, client, auth_headers_assistant):
        with patch("app.api.sa_routes.db.get_assistant_by_email", return_value=None):
            resp = client.get("/sa/dashboard", headers=auth_headers_assistant)

        assert resp.status_code == 404

    def test_returns_401_without_auth_header(self, client):
        resp = client.get("/sa/dashboard")
        assert resp.status_code == 403  # HTTPBearer returns 403 when header missing


class TestCheckin:

    def test_successful_checkin_returns_200(self, client, auth_headers_assistant, enrolled_assistant, sample_face_base64):
        mock_result = CheckinResponse(
            success=True,
            within_radius=True,
            face_match_score=91,
            face_match_status="Match",
            checkin_method=CheckinMethod.FACE_GPS,
            message="Check-in recorded.",
        )
        with (
            patch("app.api.sa_routes.db.get_assistant_by_email", return_value=enrolled_assistant),
            patch("app.api.sa_routes.process_checkin", new=AsyncMock(return_value=mock_result)),
        ):
            resp = client.post("/sa/checkin", headers=auth_headers_assistant, json={
                "lat": 6.5244, "lng": 3.3792,
                "comment": "Morning",
                "face_image_base64": sample_face_base64,
            })

        assert resp.status_code == 200
        assert resp.json()["success"] is True
        assert resp.json()["face_match_score"] == 91

    def test_rejects_invalid_coordinates(self, client, auth_headers_assistant, enrolled_assistant, sample_face_base64):
        with patch("app.api.sa_routes.db.get_assistant_by_email", return_value=enrolled_assistant):
            resp = client.post("/sa/checkin", headers=auth_headers_assistant, json={
                "lat": 999,  # invalid
                "lng": 3.3792,
                "face_image_base64": sample_face_base64,
            })

        assert resp.status_code == 422

    def test_face_fail_returns_can_request_override(self, client, auth_headers_assistant, enrolled_assistant, sample_face_base64):
        mock_result = CheckinResponse(
            success=False,
            within_radius=True,
            face_match_score=55,
            face_match_status="No Match",
            message="Face did not match.",
            can_request_override=True,
        )
        with (
            patch("app.api.sa_routes.db.get_assistant_by_email", return_value=enrolled_assistant),
            patch("app.api.sa_routes.process_checkin", new=AsyncMock(return_value=mock_result)),
        ):
            resp = client.post("/sa/checkin", headers=auth_headers_assistant, json={
                "lat": 6.5244, "lng": 3.3792,
                "face_image_base64": sample_face_base64,
            })

        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is False
        assert data["can_request_override"] is True


class TestEnrollment:

    def test_submit_enrollment_returns_pending(self, client, auth_headers_assistant, unenrolled_assistant, sample_face_base64):
        with (
            patch("app.api.sa_routes.db.get_assistant_by_email", return_value=unenrolled_assistant),
            patch("app.api.sa_routes.db.log_enrollment_request"),
            patch("app.api.sa_routes.db.update_assistant_enrollment"),
        ):
            resp = client.post("/sa/enroll", headers=auth_headers_assistant, json={
                "face_image_base64": sample_face_base64,
                "firebase_storage_url": "https://storage.googleapis.com/test/enrollments/SKSA-0003.jpg",
            })

        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["status"] == "PENDING"

    def test_already_enrolled_returns_ok_false(self, client, auth_headers_assistant, enrolled_assistant, sample_face_base64):
        with patch("app.api.sa_routes.db.get_assistant_by_email", return_value=enrolled_assistant):
            resp = client.post("/sa/enroll", headers=auth_headers_assistant, json={
                "face_image_base64": sample_face_base64,
                "firebase_storage_url": "https://storage.googleapis.com/test/x.jpg",
            })

        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is False
        assert "already enrolled" in data["message"].lower()

    def test_pending_enrollment_blocks_resubmission(self, client, auth_headers_assistant, pending_assistant, sample_face_base64):
        with patch("app.api.sa_routes.db.get_assistant_by_email", return_value=pending_assistant):
            resp = client.post("/sa/enroll", headers=auth_headers_assistant, json={
                "face_image_base64": sample_face_base64,
                "firebase_storage_url": "https://storage.googleapis.com/test/x.jpg",
            })

        assert resp.status_code == 200
        assert resp.json()["ok"] is False
        assert "pending" in resp.json()["message"].lower()


class TestCheckinHistory:

    def test_returns_history_for_current_month(self, client, auth_headers_assistant, enrolled_assistant):
        mock_items = [
            {"timestamp_iso": "2026-03-01T08:00:00", "assistant_id": "SKSA-0001",
             "distance_m": "45.2", "within_radius": True, "comment": "", "face_match_score": "91", "checkin_method": "FACE+GPS"},
        ]
        with (
            patch("app.api.sa_routes.db.get_assistant_by_email", return_value=enrolled_assistant),
            patch("app.api.sa_routes.db.get_monthly_valid_checkins", return_value=mock_items),
        ):
            resp = client.get("/sa/checkins/history", headers=auth_headers_assistant)

        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert len(data["items"]) == 1


# ═══════════════════════════════════════════════════════════════════
# SUPERVISOR PORTAL
# ═══════════════════════════════════════════════════════════════════

class TestSupervisorAssistants:

    def test_returns_team_with_attendance_summary(self, client, auth_headers_supervisor, enrolled_assistant):
        from app.models.schemas import AssistantAttendanceSummary
        mock_summary = AssistantAttendanceSummary(
            assistant_id="SKSA-0001",
            assistant_name="Tunde Adeola",
            assistant_email="tunde@sunking.com",
            shop_id="SHOP-001",
            shop_area="Lagos Island",
            checkins=18,
            working_days=26,
            percentage="69%",
            passed=False,
            validation_status=ValidationStatus.PENDING,
        )
        from app.models.schemas import SupervisorAssistantsResponse
        mock_response = SupervisorAssistantsResponse(
            month=3, year=2026, working_days=26, assistants=[mock_summary]
        )
        with patch("app.api.sa_routes.db.get_assistants_for_supervisor", return_value=[enrolled_assistant]):
            with patch("app.api.sa_routes.db._working_days", return_value=26):
                with patch("app.api.sa_routes.db.get_unique_valid_days_by_assistant", return_value={"SKSA-0001": 18}):
                    with patch("app.api.sa_routes.db.get_validation_status_map", return_value={}):
                        resp = client.get("/sa/supervisor/assistants", headers=auth_headers_supervisor)

        assert resp.status_code == 200
        data = resp.json()
        assert data["working_days"] == 26
        assert len(data["assistants"]) == 1
        assert data["assistants"][0]["checkins"] == 18

    def test_returns_404_when_no_assistants_assigned(self, client, auth_headers_supervisor):
        with patch("app.api.sa_routes.db.get_assistants_for_supervisor", return_value=[]):
            resp = client.get("/sa/supervisor/assistants", headers=auth_headers_supervisor)

        assert resp.status_code == 404


class TestSupervisorValidation:

    def test_validates_assigned_assistant(self, client, auth_headers_supervisor, enrolled_assistant):
        with (
            patch("app.api.sa_routes.db.get_assistant_by_id", return_value=enrolled_assistant),
            patch("app.api.sa_routes.db._working_days", return_value=26),
            patch("app.api.sa_routes.db.get_unique_valid_days_by_assistant", return_value={"SKSA-0001": 20}),
            patch("app.api.sa_routes.db.log_validation"),
        ):
            resp = client.post("/sa/supervisor/validate", headers=auth_headers_supervisor, json={
                "assistant_id": "SKSA-0001",
                "month": 3, "year": 2026,
                "status": "APPROVED",
                "comment": "Good attendance",
            })

        assert resp.status_code == 200
        assert resp.json()["ok"] is True

    def test_rejects_validation_for_unassigned_assistant(self, client, auth_headers_supervisor, enrolled_assistant):
        # Supervisor email doesn't match assistant's supervisor
        enrolled_assistant.supervisor_email = "other.supervisor@sunking.com"
        with patch("app.api.sa_routes.db.get_assistant_by_id", return_value=enrolled_assistant):
            resp = client.post("/sa/supervisor/validate", headers=auth_headers_supervisor, json={
                "assistant_id": "SKSA-0001",
                "month": 3, "year": 2026,
                "status": "APPROVED",
            })

        assert resp.status_code == 403


class TestSupervisorOverride:

    def test_successful_override_returns_checkin_response(self, client, auth_headers_supervisor, enrolled_assistant, sample_face_base64):
        mock_result = CheckinResponse(
            success=True,
            within_radius=True,
            checkin_method=CheckinMethod.SUPERVISOR_OVERRIDE,
            message="Override check-in recorded. 2 override(s) remaining this month.",
        )
        with (
            patch("app.api.sa_routes.db.get_assistant_by_id", return_value=enrolled_assistant),
            patch("app.api.sa_routes.db.get_shop_coords", return_value=(6.5244, 3.3792, "Test Shop")),
            patch("app.api.sa_routes.process_override", return_value=mock_result),
        ):
            resp = client.post("/sa/supervisor/override", headers=auth_headers_supervisor, json={
                "assistant_id": "SKSA-0001",
                "assistant_email": "tunde@sunking.com",
                "comment": "Camera issue",
            })

        assert resp.status_code == 200
        assert resp.json()["success"] is True
        assert resp.json()["checkin_method"] == "SUPERVISOR_OVERRIDE"

    def test_override_count_endpoint(self, client, auth_headers_supervisor):
        with patch("app.api.sa_routes.db.get_override_count", return_value=1):
            resp = client.get("/sa/supervisor/override-count/SKSA-0001", headers=auth_headers_supervisor)

        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 1
        assert data["remaining"] == 2
        assert data["max_overrides"] == 3


# ═══════════════════════════════════════════════════════════════════
# HR PORTAL
# ═══════════════════════════════════════════════════════════════════

class TestHREnrollmentRequests:

    def test_hr_can_fetch_pending_enrollments(self, client, auth_headers_hr):
        pending = [
            EnrollmentRequest(
                assistant_id="SKSA-0003",
                assistant_name="Chidi Nwosu",
                email="chidi@sunking.com",
                photo_url="https://storage.googleapis.com/test/x.jpg",
                request_date="2026-03-01T08:00:00",
            )
        ]
        with (
            patch("app.api.sa_routes.db.is_hr_user", return_value=True),
            patch("app.api.sa_routes.db.get_pending_enrollments", return_value=pending),
        ):
            resp = client.get("/sa/hr/enrollment-requests", headers=auth_headers_hr)

        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert len(data["items"]) == 1
        assert data["items"][0]["assistant_id"] == "SKSA-0003"

    def test_non_hr_user_gets_403(self, client, auth_headers_assistant):
        with patch("app.api.sa_routes.db.is_hr_user", return_value=False):
            resp = client.get("/sa/hr/enrollment-requests", headers=auth_headers_assistant)

        assert resp.status_code == 403

    def test_approve_enrollment_activates_reference_photo(self, client, auth_headers_hr):
        pending = [EnrollmentRequest(
            assistant_id="SKSA-0003", assistant_name="Chidi",
            email="chidi@sunking.com",
            photo_url="https://storage.googleapis.com/test/x.jpg",
            request_date="2026-03-01",
        )]
        with (
            patch("app.api.sa_routes.db.is_hr_user", return_value=True),
            patch("app.api.sa_routes.db.get_pending_enrollments", return_value=pending),
            patch("app.api.sa_routes.db.update_enrollment_log"),
            patch("app.api.sa_routes.db.update_assistant_enrollment") as mock_update,
        ):
            resp = client.post(
                "/sa/hr/enrollment/SKSA-0003/approve",
                headers=auth_headers_hr,
                json={"assistant_id": "SKSA-0003", "comment": "Looks good"},
            )

        assert resp.status_code == 200
        assert resp.json()["ok"] is True
        mock_update.assert_called_once()
        call_kwargs = mock_update.call_args.kwargs
        assert call_kwargs["status"] == EnrollmentStatus.ENROLLED
        assert call_kwargs["photo_url"] == "https://storage.googleapis.com/test/x.jpg"

    def test_reject_enrollment_sets_rejected_status(self, client, auth_headers_hr):
        with (
            patch("app.api.sa_routes.db.is_hr_user", return_value=True),
            patch("app.api.sa_routes.db.update_enrollment_log"),
            patch("app.api.sa_routes.db.update_assistant_enrollment") as mock_update,
        ):
            resp = client.post(
                "/sa/hr/enrollment/SKSA-0003/reject",
                headers=auth_headers_hr,
                json={"assistant_id": "SKSA-0003", "comment": "Photo too dark"},
            )

        assert resp.status_code == 200
        mock_update.assert_called_once()
        assert mock_update.call_args.kwargs["status"] == EnrollmentStatus.REJECTED


class TestHROverview:

    def test_returns_full_overview_with_all_columns(self, client, auth_headers_hr):
        mock_assistants = [{
            "assistant id": "SKSA-0001", "assistant name": "Tunde",
            "assistant email": "tunde@sunking.com", "shop id": "SHOP-001",
            "shoparea": "Lagos", "supervisor email": "sup@sunking.com",
            "enrollment status": "ENROLLED",
        }]
        with (
            patch("app.api.sa_routes.db.is_hr_user", return_value=True),
            patch("app.api.sa_routes.db.sheet_to_dicts", return_value=mock_assistants),
            patch("app.api.sa_routes.db.SHEETS"),
            patch("app.api.sa_routes.db._working_days", return_value=26),
            patch("app.api.sa_routes.db.get_unique_valid_days_by_assistant", return_value={"SKSA-0001": 20}),
            patch("app.api.sa_routes.db.get_all_validation_status_map", return_value={}),
            patch("app.api.sa_routes.db.get_hr_decisions_map", return_value={}),
        ):
            resp = client.get("/sa/hr/overview?month=3&year=2026", headers=auth_headers_hr)

        assert resp.status_code == 200
        data = resp.json()
        assert data["working_days"] == 26
        assert len(data["rows"]) == 1
        row = data["rows"][0]
        assert row["checkins"] == 20
        assert row["passed"] is True  # 20/26 = 76%


class TestHRDecision:

    def test_hr_validates_assistant(self, client, auth_headers_hr):
        with (
            patch("app.api.sa_routes.db.is_hr_user", return_value=True),
            patch("app.api.sa_routes.db.log_hr_decision"),
        ):
            resp = client.post("/sa/hr/decision", headers=auth_headers_hr, json={
                "assistant_id": "SKSA-0001",
                "month": 3, "year": 2026,
                "assistant_email": "tunde@sunking.com",
                "decision": "VALIDATED",
                "comment": "Meets threshold",
            })

        assert resp.status_code == 200
        assert resp.json()["hr_status"] == "VALIDATED"

    def test_hr_marks_ineligible(self, client, auth_headers_hr):
        with (
            patch("app.api.sa_routes.db.is_hr_user", return_value=True),
            patch("app.api.sa_routes.db.log_hr_decision"),
        ):
            resp = client.post("/sa/hr/decision", headers=auth_headers_hr, json={
                "assistant_id": "SKSA-0002",
                "month": 3, "year": 2026,
                "assistant_email": "amaka@sunking.com",
                "decision": "INELIGIBLE",
                "comment": "Below 70%",
            })

        assert resp.status_code == 200
        assert resp.json()["hr_status"] == "INELIGIBLE"


class TestExport:

    def test_export_returns_csv_with_correct_headers(self, client, auth_headers_hr):
        csv_data = "AssistantID,Name,Email,ShopArea,BankName,AccountNumber,Amount,Currency,Month,Year\nSKSA-0001,Tunde,tunde@sunking.com,Lagos,,, 50000,NGN,3,2026\n"
        with (
            patch("app.api.sa_routes.db.is_hr_user", return_value=True),
            patch("app.api.sa_routes.db.build_approved_csv", return_value=(csv_data, 1)),
        ):
            resp = client.get("/sa/hr/export?month=3&year=2026", headers=auth_headers_hr)

        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True
        assert data["count"] == 1
        assert "AssistantID" in data["csv"]
        assert data["filename"] == "Approved_SA_2026_03.csv"
