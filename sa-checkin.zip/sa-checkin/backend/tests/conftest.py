"""
Shared fixtures for all SA Check-In backend tests.
All external dependencies (Sheets, Rekognition, Firebase) are mocked at the boundary.
"""
import base64
import json
import pytest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient

from app.main import app
from app.models.schemas import AssistantProfile, EnrollmentStatus


# ── App client ────────────────────────────────────────────────────────────────

@pytest.fixture
def client():
    return TestClient(app)


# ── Auth bypass ───────────────────────────────────────────────────────────────

@pytest.fixture
def auth_headers_assistant():
    """Bypasses Firebase token verification — returns assistant email."""
    with patch("app.core.auth.auth.verify_id_token") as mock_verify:
        mock_verify.return_value = {
            "uid": "uid-assistant-1",
            "email": "tunde@sunking.com",
        }
        yield {"Authorization": "Bearer fake-assistant-token"}


@pytest.fixture
def auth_headers_supervisor():
    with patch("app.core.auth.auth.verify_id_token") as mock_verify:
        mock_verify.return_value = {
            "uid": "uid-supervisor-1",
            "email": "supervisor@sunking.com",
        }
        yield {"Authorization": "Bearer fake-supervisor-token"}


@pytest.fixture
def auth_headers_hr():
    with patch("app.core.auth.auth.verify_id_token") as mock_verify:
        mock_verify.return_value = {
            "uid": "uid-hr-1",
            "email": "hr@sunking.com",
        }
        yield {"Authorization": "Bearer fake-hr-token"}


# ── Sample data ───────────────────────────────────────────────────────────────

@pytest.fixture
def enrolled_assistant():
    return AssistantProfile(
        assistant_id="SKSA-0001",
        assistant_name="Tunde Adeola",
        email="tunde@sunking.com",
        shop_id="SHOP-001",
        shop_area="Lagos Island",
        supervisor_email="supervisor@sunking.com",
        enrollment_status=EnrollmentStatus.ENROLLED,
        reference_photo_url="https://firebasestorage.googleapis.com/v0/b/test/o/enrollments%2FSKSA-0001.jpg",
    )


@pytest.fixture
def pending_assistant():
    return AssistantProfile(
        assistant_id="SKSA-0002",
        assistant_name="Amaka Obi",
        email="amaka@sunking.com",
        shop_id="SHOP-002",
        shop_area="Abuja",
        supervisor_email="supervisor@sunking.com",
        enrollment_status=EnrollmentStatus.PENDING,
        reference_photo_url=None,
    )


@pytest.fixture
def unenrolled_assistant():
    return AssistantProfile(
        assistant_id="SKSA-0003",
        assistant_name="Chidi Nwosu",
        email="chidi@sunking.com",
        shop_id="SHOP-003",
        shop_area="Port Harcourt",
        supervisor_email="supervisor@sunking.com",
        enrollment_status=EnrollmentStatus.NONE,
        reference_photo_url=None,
    )


@pytest.fixture
def sample_face_base64():
    """Minimal valid base64 JPEG bytes."""
    return base64.b64encode(b"\xff\xd8\xff\xe0" + b"\x00" * 100).decode()


# ── Settings override ─────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def mock_settings(monkeypatch):
    """Override settings to avoid needing real env vars in tests."""
    monkeypatch.setenv("GOOGLE_SHEETS_SPREADSHEET_ID", "test-spreadsheet-id")
    monkeypatch.setenv("GOOGLE_SERVICE_ACCOUNT_JSON",
        base64.b64encode(json.dumps({
            "type": "service_account",
            "project_id": "test",
            "private_key_id": "key-id",
            "private_key": "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0Z3VS5JJcds3xHn/ygWep4PAtE\n-----END RSA PRIVATE KEY-----\n",
            "client_email": "test@test.iam.gserviceaccount.com",
            "client_id": "123",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
        }).encode()).decode()
    )
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "test-key")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "test-secret")
    monkeypatch.setenv("AWS_REGION", "us-east-1")
    monkeypatch.setenv("FIREBASE_PROJECT_ID", "test-project")
    monkeypatch.setenv("FIREBASE_SERVICE_ACCOUNT_JSON",
        base64.b64encode(json.dumps({
            "type": "service_account",
            "project_id": "test",
            "private_key_id": "key-id",
            "private_key": "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0Z3VS5JJcds3xHn/ygWep4PAtE\n-----END RSA PRIVATE KEY-----\n",
            "client_email": "test@test.iam.gserviceaccount.com",
            "client_id": "123",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
        }).encode()).decode()
    )
    monkeypatch.setenv("SA_FACE_THRESHOLD", "80")
    monkeypatch.setenv("SA_MAX_OVERRIDES", "3")
    monkeypatch.setenv("SA_CHECKIN_RADIUS_M", "200")
