"""
Tests for app/services/checkin_service.py
TDD: define expected behaviour for every check-in scenario before running.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from app.models.schemas import EnrollmentStatus, CheckinMethod
from app.services.checkin_service import haversine_distance, process_checkin, process_override


# ── haversine_distance ────────────────────────────────────────────────────────

class TestHaversineDistance:

    def test_same_point_is_zero(self):
        assert haversine_distance(6.5244, 3.3792, 6.5244, 3.3792) == pytest.approx(0, abs=1)

    def test_known_distance_lagos(self):
        # Victoria Island to Lekki Phase 1 — approx 7km
        dist = haversine_distance(6.4281, 3.4219, 6.4477, 3.5264)
        assert 6000 < dist < 9000

    def test_200m_boundary(self):
        # Move ~150m north of a point — should be under 200m
        dist = haversine_distance(6.5244, 3.3792, 6.5258, 3.3792)
        assert dist < 200

    def test_beyond_200m(self):
        # Move ~500m north
        dist = haversine_distance(6.5244, 3.3792, 6.5289, 3.3792)
        assert dist > 200


# ── process_checkin ───────────────────────────────────────────────────────────

class TestProcessCheckin:

    @pytest.mark.asyncio
    async def test_blocks_duplicate_checkin(self, enrolled_assistant, sample_face_base64):
        """If assistant already has a valid check-in today, reject immediately."""
        with patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=True):
            result = await process_checkin(
                assistant=enrolled_assistant,
                lat=6.5244, lng=3.3792,
                comment="",
                face_image_base64=sample_face_base64,
            )
        assert result.success is False
        assert "already" in result.message.lower()

    @pytest.mark.asyncio
    async def test_blocks_unenrolled_assistant(self, unenrolled_assistant, sample_face_base64):
        """Assistant with NONE enrollment status should be blocked and told to enrol."""
        with patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False):
            result = await process_checkin(
                assistant=unenrolled_assistant,
                lat=6.5244, lng=3.3792,
                comment="",
                face_image_base64=sample_face_base64,
            )
        assert result.success is False
        assert result.enrollment_required is True
        assert result.enrollment_status == EnrollmentStatus.NONE

    @pytest.mark.asyncio
    async def test_blocks_pending_enrollment(self, pending_assistant, sample_face_base64):
        """Assistant with PENDING enrollment should be told to wait for HR."""
        with patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False):
            result = await process_checkin(
                assistant=pending_assistant,
                lat=6.5244, lng=3.3792,
                comment="",
                face_image_base64=sample_face_base64,
            )
        assert result.success is False
        assert result.enrollment_required is True
        assert "pending" in result.message.lower()

    @pytest.mark.asyncio
    async def test_successful_checkin_within_radius(self, enrolled_assistant, sample_face_base64):
        """Valid face + within 200m = successful check-in."""
        with (
            patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False),
            patch("app.services.checkin_service.db.get_shop_coords", return_value=(6.5244, 3.3792, "Test Shop")),
            patch("app.services.checkin_service.db.log_checkin"),
            patch("app.services.checkin_service.compare_faces") as mock_face,
            patch("app.services.checkin_service.httpx.AsyncClient") as mock_http,
        ):
            mock_face.return_value = MagicMock(ok=True, similarity=92)
            mock_http.return_value.__aenter__.return_value.get = AsyncMock(
                return_value=MagicMock(content=b"fake_photo", raise_for_status=MagicMock())
            )

            result = await process_checkin(
                assistant=enrolled_assistant,
                lat=6.5244, lng=3.3792,  # exactly at shop
                comment="Morning shift",
                face_image_base64=sample_face_base64,
            )

        assert result.success is True
        assert result.within_radius is True
        assert result.face_match_score == 92
        assert result.checkin_method == CheckinMethod.FACE_GPS

    @pytest.mark.asyncio
    async def test_checkin_out_of_range_but_face_passes(self, enrolled_assistant, sample_face_base64):
        """Face passes but outside 200m — still logged, success=True, within_radius=False."""
        with (
            patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False),
            patch("app.services.checkin_service.db.get_shop_coords", return_value=(6.5244, 3.3792, "Test Shop")),
            patch("app.services.checkin_service.db.log_checkin"),
            patch("app.services.checkin_service.compare_faces") as mock_face,
            patch("app.services.checkin_service.httpx.AsyncClient") as mock_http,
        ):
            mock_face.return_value = MagicMock(ok=True, similarity=90)
            mock_http.return_value.__aenter__.return_value.get = AsyncMock(
                return_value=MagicMock(content=b"fake_photo", raise_for_status=MagicMock())
            )

            result = await process_checkin(
                assistant=enrolled_assistant,
                lat=6.5300, lng=3.4000,  # far from shop
                comment="",
                face_image_base64=sample_face_base64,
            )

        assert result.success is True
        assert result.within_radius is False

    @pytest.mark.asyncio
    async def test_face_below_threshold_offers_override(self, enrolled_assistant, sample_face_base64):
        """Face similarity below 80% — fail with can_request_override=True."""
        with (
            patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False),
            patch("app.services.checkin_service.db.get_shop_coords", return_value=(6.5244, 3.3792, "Test Shop")),
            patch("app.services.checkin_service.compare_faces") as mock_face,
            patch("app.services.checkin_service.httpx.AsyncClient") as mock_http,
        ):
            mock_face.return_value = MagicMock(ok=True, similarity=62)
            mock_http.return_value.__aenter__.return_value.get = AsyncMock(
                return_value=MagicMock(content=b"fake_photo", raise_for_status=MagicMock())
            )

            result = await process_checkin(
                assistant=enrolled_assistant,
                lat=6.5244, lng=3.3792,
                comment="",
                face_image_base64=sample_face_base64,
            )

        assert result.success is False
        assert result.can_request_override is True
        assert result.face_match_score == 62

    @pytest.mark.asyncio
    async def test_rekognition_api_error_offers_override(self, enrolled_assistant, sample_face_base64):
        """Rekognition failure (ok=False) should also offer override."""
        with (
            patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False),
            patch("app.services.checkin_service.db.get_shop_coords", return_value=(6.5244, 3.3792, "Test Shop")),
            patch("app.services.checkin_service.compare_faces") as mock_face,
            patch("app.services.checkin_service.httpx.AsyncClient") as mock_http,
        ):
            mock_face.return_value = MagicMock(ok=False, similarity=0, error="API error")
            mock_http.return_value.__aenter__.return_value.get = AsyncMock(
                return_value=MagicMock(content=b"fake_photo", raise_for_status=MagicMock())
            )

            result = await process_checkin(
                assistant=enrolled_assistant,
                lat=6.5244, lng=3.3792,
                comment="",
                face_image_base64=sample_face_base64,
            )

        assert result.success is False
        assert result.can_request_override is True


# ── process_override ──────────────────────────────────────────────────────────

class TestProcessOverride:

    def test_blocks_wrong_supervisor(self, enrolled_assistant):
        """Wrong supervisor email must be rejected."""
        result = process_override(
            assistant=enrolled_assistant,
            supervisor_email="imposter@sunking.com",
            lat=6.5244, lng=3.3792,
            comment="",
        )
        assert result.success is False
        assert "not the assigned supervisor" in result.message.lower()

    def test_blocks_when_override_cap_reached(self, enrolled_assistant):
        """3/3 overrides used — 4th should be blocked."""
        with (
            patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False),
            patch("app.services.checkin_service.db.get_shop_coords", return_value=(6.5244, 3.3792, "Test Shop")),
            patch("app.services.checkin_service.db.get_override_count", return_value=3),
        ):
            result = process_override(
                assistant=enrolled_assistant,
                supervisor_email="supervisor@sunking.com",
                lat=6.5244, lng=3.3792,
                comment="",
            )

        assert result.success is False
        assert "limit" in result.message.lower()

    def test_successful_override_within_cap(self, enrolled_assistant):
        """First override of the month — should succeed and return remaining count."""
        with (
            patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=False),
            patch("app.services.checkin_service.db.get_shop_coords", return_value=(6.5244, 3.3792, "Test Shop")),
            patch("app.services.checkin_service.db.get_override_count", return_value=0),
            patch("app.services.checkin_service.db.record_override", return_value=1),
            patch("app.services.checkin_service.db.log_checkin"),
        ):
            result = process_override(
                assistant=enrolled_assistant,
                supervisor_email="supervisor@sunking.com",
                lat=6.5244, lng=3.3792,
                comment="Camera broken",
            )

        assert result.success is True
        assert result.checkin_method == CheckinMethod.SUPERVISOR_OVERRIDE
        assert "2" in result.message  # 2 remaining

    def test_blocks_duplicate_override(self, enrolled_assistant):
        """Supervisor override must also respect the duplicate check-in guard."""
        with patch("app.services.checkin_service.db.has_valid_checkin_today", return_value=True):
            result = process_override(
                assistant=enrolled_assistant,
                supervisor_email="supervisor@sunking.com",
                lat=6.5244, lng=3.3792,
                comment="",
            )

        assert result.success is False
        assert "already" in result.message.lower()
