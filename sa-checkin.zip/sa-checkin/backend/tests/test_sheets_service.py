"""
Tests for app/services/sheets_service.py
Pure data layer tests — no real Sheets API calls, all mocked.
"""
import pytest
from unittest.mock import patch
from datetime import datetime

from app.models.schemas import EnrollmentStatus, ValidationStatus
from app.services import sheets_service as db


class TestWorkingDays:

    def test_march_2026_has_correct_weekdays(self):
        # March 2026: 27 Mon–Sat days (no public holidays in sheet model)
        count = db._working_days(3, 2026)
        assert count == 27

    def test_february_2024_leap_year(self):
        # Feb 2024: 24 Mon–Sat days
        count = db._working_days(2, 2024)
        assert count == 25

    def test_no_sundays_counted(self):
        # Every month should have fewer than 32 days and no Sundays
        for month in range(1, 13):
            count = db._working_days(month, 2026)
            assert count <= 27


class TestGetAssistantByEmail:

    def test_returns_profile_for_matching_email(self):
        mock_rows = [{
            "assistant email": "tunde@sunking.com",
            "assistant name": "Tunde Adeola",
            "assistant id": "SKSA-0001",
            "shop id": "SHOP-001",
            "shoparea": "Lagos Island",
            "supervisor email": "sup@sunking.com",
            "enrollment status": "ENROLLED",
            "reference photo url": "https://storage.test/x.jpg",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            result = db.get_assistant_by_email("tunde@sunking.com")

        assert result is not None
        assert result.assistant_id == "SKSA-0001"
        assert result.enrollment_status == EnrollmentStatus.ENROLLED

    def test_email_lookup_is_case_insensitive(self):
        mock_rows = [{
            "assistant email": "TUNDE@SUNKING.COM",
            "assistant name": "Tunde", "assistant id": "SKSA-0001",
            "shop id": "SHOP-001", "shoparea": "Lagos",
            "supervisor email": "sup@sunking.com",
            "enrollment status": "ENROLLED", "reference photo url": "",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            result = db.get_assistant_by_email("tunde@sunking.com")

        assert result is not None

    def test_returns_none_for_unknown_email(self):
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=[]):
            result = db.get_assistant_by_email("ghost@sunking.com")

        assert result is None

    def test_defaults_unknown_enrollment_status_to_none(self):
        mock_rows = [{
            "assistant email": "x@sunking.com", "assistant name": "X",
            "assistant id": "SKSA-X", "shop id": "S1", "shoparea": "Area",
            "supervisor email": "s@s.com", "enrollment status": "UNKNOWN_STATUS",
            "reference photo url": "",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            result = db.get_assistant_by_email("x@sunking.com")

        assert result.enrollment_status == EnrollmentStatus.NONE


class TestHasValidCheckinToday:

    def test_returns_true_when_valid_checkin_exists_today(self):
        today = datetime.utcnow()
        mock_rows = [{
            "assistantid": "SKSA-0001",
            "timestamp": today.isoformat(),
            "status": "Valid",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            assert db.has_valid_checkin_today("SKSA-0001") is True

    def test_returns_false_when_no_checkin_today(self):
        mock_rows = [{
            "assistantid": "SKSA-0001",
            "timestamp": "2026-01-01T08:00:00",
            "status": "Valid",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            assert db.has_valid_checkin_today("SKSA-0001") is False

    def test_returns_false_for_out_of_range_status(self):
        today = datetime.utcnow()
        mock_rows = [{
            "assistantid": "SKSA-0001",
            "timestamp": today.isoformat(),
            "status": "Out of Range",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            assert db.has_valid_checkin_today("SKSA-0001") is False

    def test_returns_false_for_different_assistant(self):
        today = datetime.utcnow()
        mock_rows = [{
            "assistantid": "SKSA-9999",  # different ID
            "timestamp": today.isoformat(),
            "status": "Valid",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            assert db.has_valid_checkin_today("SKSA-0001") is False


class TestGetUniqueValidDaysByAssistant:

    def test_counts_unique_days_not_duplicate_checkins(self):
        today = datetime(2026, 3, 10)
        mock_rows = [
            {"assistantid": "SKSA-0001", "timestamp": "2026-03-10T08:00:00", "status": "Valid"},
            {"assistantid": "SKSA-0001", "timestamp": "2026-03-10T09:30:00", "status": "Valid"},  # same day
            {"assistantid": "SKSA-0001", "timestamp": "2026-03-11T08:00:00", "status": "Valid"},
        ]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            result = db.get_unique_valid_days_by_assistant(3, 2026)

        assert result.get("SKSA-0001") == 2  # 2 unique days, not 3 rows

    def test_ignores_out_of_range_checkins(self):
        mock_rows = [
            {"assistantid": "SKSA-0001", "timestamp": "2026-03-10T08:00:00", "status": "Out of Range"},
        ]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            result = db.get_unique_valid_days_by_assistant(3, 2026)

        assert result.get("SKSA-0001", 0) == 0

    def test_ignores_wrong_month(self):
        mock_rows = [
            {"assistantid": "SKSA-0001", "timestamp": "2026-02-28T08:00:00", "status": "Valid"},
        ]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            result = db.get_unique_valid_days_by_assistant(3, 2026)

        assert result.get("SKSA-0001", 0) == 0


class TestGetOverrideCount:

    def test_returns_count_for_current_month(self):
        now = datetime.utcnow()
        mock_rows = [{
            "assistantid": "SKSA-0001",
            "month": str(now.month),
            "year": str(now.year),
            "overridecount": "2",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            count = db.get_override_count("SKSA-0001", now.month, now.year)

        assert count == 2

    def test_returns_zero_when_no_override_record(self):
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=[]):
            count = db.get_override_count("SKSA-0001", 3, 2026)

        assert count == 0

    def test_returns_zero_for_different_month(self):
        mock_rows = [{
            "assistantid": "SKSA-0001",
            "month": "2",  # February
            "year": "2026",
            "overridecount": "3",
        }]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            count = db.get_override_count("SKSA-0001", 3, 2026)  # March

        assert count == 0


class TestIsHRUser:

    def test_returns_true_for_hr_email(self):
        mock_rows = [{"hr email": "hr@sunking.com"}]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            assert db.is_hr_user("hr@sunking.com") is True

    def test_returns_false_for_non_hr_email(self):
        mock_rows = [{"hr email": "hr@sunking.com"}]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            assert db.is_hr_user("field@sunking.com") is False

    def test_case_insensitive_hr_lookup(self):
        mock_rows = [{"hr email": "HR@SUNKING.COM"}]
        with patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_rows):
            assert db.is_hr_user("hr@sunking.com") is True


class TestBuildApprovedCSV:

    def test_csv_contains_validated_assistants_only(self):
        mock_assistants = [
            {
                "assistant id": "SKSA-0001", "assistant name": "Tunde",
                "assistant email": "tunde@sunking.com", "shoparea": "Lagos",
                "bank name": "GTB", "account number": "0123456789",
            },
            {
                "assistant id": "SKSA-0002", "assistant name": "Amaka",
                "assistant email": "amaka@sunking.com", "shoparea": "Abuja",
                "bank name": "Access", "account number": "9876543210",
            },
        ]
        mock_hr_decisions = {
            "SKSA-0001": {"decision": "VALIDATED"},
            "SKSA-0002": {"decision": "INELIGIBLE"},  # should be excluded
        }
        with (
            patch("app.services.sheets_service.sheet_to_dicts", return_value=mock_assistants),
            patch("app.services.sheets_service.get_hr_decisions_map", return_value=mock_hr_decisions),
        ):
            csv_str, count = db.build_approved_csv(3, 2026)

        assert count == 1
        assert "SKSA-0001" in csv_str
        assert "SKSA-0002" not in csv_str
        assert "50000" in csv_str
        assert "NGN" in csv_str
