# SA Face Check-In — Full Stack

## Stack
- **Backend**: FastAPI + boto3 (Rekognition) + Google Sheets API + Firebase Admin
- **Frontend**: React + TypeScript + Firebase Storage (camera, GPS)
- **Tests**: pytest (backend) + Vitest + React Testing Library (frontend)
- **TDD**: Every file has a companion test. No production code without a red test first.

## Structure
```
sa-checkin/
├── backend/
│   ├── app/
│   │   ├── core/          # config, auth, sheets client, firebase
│   │   ├── models/        # Pydantic request/response schemas
│   │   ├── services/      # business logic (checkin, enrollment, rekognition)
│   │   └── api/           # FastAPI routers
│   └── tests/             # pytest — mirrors app/ structure
└── frontend/
    ├── src/
    │   ├── api/            # API client functions
    │   ├── hooks/          # useCamera, useGeolocation, useCheckin etc.
    │   ├── types/          # TypeScript interfaces
    │   └── components/
    │       └── shop-assistant/
    │           ├── AssistantPortal.tsx
    │           ├── SupervisorPortal.tsx
    │           └── HRPortal.tsx
    └── tests/             # Vitest + RTL — mirrors src/ structure
```

## Running Tests
```bash
# Backend
cd backend && pytest -v

# Frontend
cd frontend && npm run test
```

## Environment Variables
```
# Backend (.env)
GOOGLE_SHEETS_SPREADSHEET_ID=
GOOGLE_SERVICE_ACCOUNT_JSON=  # base64 encoded service account JSON
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_REGION=us-east-1
FIREBASE_PROJECT_ID=
FIREBASE_SERVICE_ACCOUNT_JSON=  # base64 encoded
SA_FACE_THRESHOLD=80
SA_MAX_OVERRIDES=3
SA_CHECKIN_RADIUS_M=200

# Frontend (.env.local)
VITE_API_BASE_URL=https://your-cloud-run-url.run.app
VITE_FIREBASE_API_KEY=
VITE_FIREBASE_AUTH_DOMAIN=
VITE_FIREBASE_PROJECT_ID=
VITE_FIREBASE_STORAGE_BUCKET=
```
