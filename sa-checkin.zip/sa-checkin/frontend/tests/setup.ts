/**
 * Vitest setup — mock all browser APIs and Firebase at the boundary.
 * Run with: vitest --config vitest.config.ts
 */
import '@testing-library/jest-dom'
import { vi } from 'vitest'

// ── Firebase mocks ────────────────────────────────────────────────────────────
vi.mock('firebase/auth', () => ({
  getAuth: vi.fn(() => ({
    currentUser: {
      getIdToken: vi.fn().mockResolvedValue('mock-firebase-token'),
      email: 'tunde@sunking.com',
    },
  })),
}))

vi.mock('firebase/storage', () => ({
  getStorage: vi.fn(() => ({})),
  ref: vi.fn(() => ({})),
  uploadString: vi.fn().mockResolvedValue({}),
  getDownloadURL: vi.fn().mockResolvedValue(
    'https://firebasestorage.googleapis.com/v0/b/test/o/enrollments%2FSKSA-0001.jpg'
  ),
}))

// ── Browser API mocks ─────────────────────────────────────────────────────────
Object.defineProperty(global.navigator, 'mediaDevices', {
  value: {
    getUserMedia: vi.fn().mockResolvedValue({
      getTracks: () => [{ stop: vi.fn() }],
    }),
  },
  writable: true,
})

Object.defineProperty(global.navigator, 'geolocation', {
  value: {
    getCurrentPosition: vi.fn((success) =>
      success({
        coords: { latitude: 6.5244, longitude: 3.3792, accuracy: 15 },
      })
    ),
  },
  writable: true,
})

// ── saApi mock (default — tests override per-case) ────────────────────────────
vi.mock('../../src/api/saApi', () => ({
  saApi: {
    getDashboard: vi.fn(),
    getCheckinHistory: vi.fn().mockResolvedValue({ ok: true, month: 3, year: 2026, items: [] }),
    submitCheckin: vi.fn(),
    submitEnrollment: vi.fn(),
    getSupervisorAssistants: vi.fn(),
    validateAssistant: vi.fn(),
    submitOverride: vi.fn(),
    getOverrideCount: vi.fn(),
    getEnrollmentRequests: vi.fn(),
    approveEnrollment: vi.fn(),
    rejectEnrollment: vi.fn(),
    getHROverview: vi.fn(),
    submitHRDecision: vi.fn(),
    exportApproved: vi.fn(),
  },
}))
