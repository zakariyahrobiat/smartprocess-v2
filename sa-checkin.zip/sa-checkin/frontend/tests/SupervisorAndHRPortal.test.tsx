/**
 * SupervisorPortal + HRPortal tests — Vitest + React Testing Library
 */
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react'
import { vi, describe, it, expect, beforeEach } from 'vitest'
import SupervisorPortal from '../../src/components/shop-assistant/SupervisorPortal'
import HRPortal from '../../src/components/shop-assistant/HRPortal'
import { saApi } from '../../src/api/saApi'
import type {
  SupervisorAssistantsResponse, HROverviewResponse, EnrollmentRequest,
} from '../../src/types/sa.types'


// ── Fixtures ──────────────────────────────────────────────────────────────────

const mockSupervisorData: SupervisorAssistantsResponse = {
  month: 3,
  year: 2026,
  working_days: 26,
  assistants: [
    {
      assistant_id: 'SKSA-0001',
      assistant_name: 'Tunde Adeola',
      assistant_email: 'tunde@sunking.com',
      shop_id: 'SHOP-001',
      shop_area: 'Lagos Island',
      checkins: 20,
      working_days: 26,
      percentage: '76%',
      passed: true,
      validation_status: 'PENDING',
      validation_comment: '',
      validation_date: null,
    },
    {
      assistant_id: 'SKSA-0002',
      assistant_name: 'Amaka Obi',
      assistant_email: 'amaka@sunking.com',
      shop_id: 'SHOP-002',
      shop_area: 'Abuja',
      checkins: 10,
      working_days: 26,
      percentage: '38%',
      passed: false,
      validation_status: 'REJECTED',
      validation_comment: 'Below threshold',
      validation_date: '2026-03-28T10:00:00',
    },
  ],
}

const mockHROverview: HROverviewResponse = {
  month: 3,
  year: 2026,
  working_days: 26,
  rows: [
    {
      assistant_id: 'SKSA-0001',
      assistant_name: 'Tunde Adeola',
      assistant_email: 'tunde@sunking.com',
      shop_id: 'SHOP-001',
      shop_area: 'Lagos Island',
      supervisor_email: 'sup@sunking.com',
      checkins: 20,
      working_days: 26,
      percentage: '76%',
      passed: true,
      supervisor_status: 'APPROVED',
      supervisor_comment: '',
      hr_status: 'PENDING_REVIEW',
      hr_comment: '',
      enrollment_status: 'ENROLLED',
    },
  ],
}

const mockEnrollmentRequests: EnrollmentRequest[] = [
  {
    assistant_id: 'SKSA-0003',
    assistant_name: 'Chidi Nwosu',
    email: 'chidi@sunking.com',
    photo_url: 'https://storage.test/chidi.jpg',
    request_date: '2026-03-15T08:00:00',
  },
]


// ═══════════════════════════════════════════════════════════════════
// SUPERVISOR PORTAL TESTS
// ═══════════════════════════════════════════════════════════════════

describe('SupervisorPortal', () => {

  beforeEach(() => {
    vi.mocked(saApi.getSupervisorAssistants).mockResolvedValue(mockSupervisorData)
  })

  it('renders assistant cards with attendance data', async () => {
    render(<SupervisorPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('assistant-card-SKSA-0001')).toBeInTheDocument()
    })
    expect(screen.getByText('Tunde Adeola')).toBeInTheDocument()
    expect(screen.getByText(/20\/26/i)).toBeInTheDocument()
    expect(screen.getByText('76%')).toBeInTheDocument()
  })

  it('shows PASS label for assistants above 70%', async () => {
    render(<SupervisorPortal />)

    await waitFor(() => screen.getByTestId('assistant-card-SKSA-0001'))
    const card = screen.getByTestId('assistant-card-SKSA-0001')
    expect(within(card).getByText('PASS')).toBeInTheDocument()
  })

  it('shows FAIL label for assistants below 70%', async () => {
    render(<SupervisorPortal />)

    await waitFor(() => screen.getByTestId('assistant-card-SKSA-0002'))
    const card = screen.getByTestId('assistant-card-SKSA-0002')
    expect(within(card).getByText('FAIL')).toBeInTheDocument()
  })

  it('filters assistants by tab', async () => {
    render(<SupervisorPortal />)

    await waitFor(() => screen.getByTestId('tab-pending'))
    fireEvent.click(screen.getByTestId('tab-pending'))

    // Only PENDING assistants should show
    await waitFor(() => {
      expect(screen.getByTestId('assistant-card-SKSA-0001')).toBeInTheDocument()
      expect(screen.queryByTestId('assistant-card-SKSA-0002')).not.toBeInTheDocument()
    })
  })

  it('filters assistants by search query', async () => {
    render(<SupervisorPortal />)

    await waitFor(() => screen.getByTestId('supervisor-search'))
    fireEvent.change(screen.getByTestId('supervisor-search'), { target: { value: 'Amaka' } })

    await waitFor(() => {
      expect(screen.queryByTestId('assistant-card-SKSA-0001')).not.toBeInTheDocument()
      expect(screen.getByTestId('assistant-card-SKSA-0002')).toBeInTheDocument()
    })
  })

  it('opens validation modal when validate button clicked', async () => {
    render(<SupervisorPortal />)

    await waitFor(() => screen.getByTestId('btn-validate-SKSA-0001'))
    fireEvent.click(screen.getByTestId('btn-validate-SKSA-0001'))

    await waitFor(() => {
      expect(screen.getByTestId('validation-modal')).toBeInTheDocument()
    })
    expect(screen.getByText(/Validate: Tunde Adeola/i)).toBeInTheDocument()
  })

  it('submits validation and closes modal', async () => {
    vi.mocked(saApi.validateAssistant).mockResolvedValue({ ok: true, message: 'Saved' })

    render(<SupervisorPortal />)
    await waitFor(() => screen.getByTestId('btn-validate-SKSA-0001'))
    fireEvent.click(screen.getByTestId('btn-validate-SKSA-0001'))

    await waitFor(() => screen.getByTestId('btn-submit-validation'))
    fireEvent.click(screen.getByTestId('btn-submit-validation'))

    await waitFor(() => {
      expect(saApi.validateAssistant).toHaveBeenCalledWith(
        expect.objectContaining({ assistant_id: 'SKSA-0001', status: 'APPROVED' })
      )
      expect(screen.queryByTestId('validation-modal')).not.toBeInTheDocument()
    })
  })

  it('closes modal when overlay clicked', async () => {
    render(<SupervisorPortal />)
    await waitFor(() => screen.getByTestId('btn-validate-SKSA-0001'))
    fireEvent.click(screen.getByTestId('btn-validate-SKSA-0001'))
    await waitFor(() => screen.getByTestId('validation-modal-overlay'))

    fireEvent.click(screen.getByTestId('validation-modal-overlay'))

    await waitFor(() => {
      expect(screen.queryByTestId('validation-modal')).not.toBeInTheDocument()
    })
  })

  it('shows tab counts', async () => {
    render(<SupervisorPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('tab-all')).toHaveTextContent('All (2)')
      expect(screen.getByTestId('tab-pending')).toHaveTextContent('Pending (1)')
      expect(screen.getByTestId('tab-rejected')).toHaveTextContent('Rejected (1)')
    })
  })
})


// ═══════════════════════════════════════════════════════════════════
// HR PORTAL TESTS
// ═══════════════════════════════════════════════════════════════════

describe('HRPortal', () => {

  beforeEach(() => {
    vi.mocked(saApi.getEnrollmentRequests).mockResolvedValue({
      ok: true,
      items: mockEnrollmentRequests,
    })
    vi.mocked(saApi.getHROverview).mockResolvedValue(mockHROverview)
  })

  it('shows pending enrollment count badge on enrollment tab', async () => {
    render(<HRPortal />)

    await waitFor(() => {
      const tab = screen.getByTestId('tab-enrollment')
      expect(within(tab).getByText('1')).toBeInTheDocument()
    })
  })

  it('renders enrollment cards with photo and details', async () => {
    render(<HRPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('enrollment-card-SKSA-0003')).toBeInTheDocument()
    })
    expect(screen.getByText('Chidi Nwosu')).toBeInTheDocument()
    expect(screen.getByText('chidi@sunking.com')).toBeInTheDocument()
  })

  it('shows empty state when no pending enrollments', async () => {
    vi.mocked(saApi.getEnrollmentRequests).mockResolvedValue({ ok: true, items: [] })

    render(<HRPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('no-enrollments')).toBeInTheDocument()
    })
  })

  it('opens enrollment review modal on Review click', async () => {
    render(<HRPortal />)

    await waitFor(() => screen.getByTestId('btn-review-SKSA-0003'))
    fireEvent.click(screen.getByTestId('btn-review-SKSA-0003'))

    await waitFor(() => {
      expect(screen.getByTestId('enrollment-review-modal')).toBeInTheDocument()
    })
    expect(screen.getByTestId('enrollment-photo')).toHaveAttribute(
      'src', 'https://storage.test/chidi.jpg'
    )
  })

  it('approves enrollment and removes card from list', async () => {
    vi.mocked(saApi.approveEnrollment).mockResolvedValue({ ok: true, message: 'Approved' })

    render(<HRPortal />)
    await waitFor(() => screen.getByTestId('btn-review-SKSA-0003'))
    fireEvent.click(screen.getByTestId('btn-review-SKSA-0003'))
    await waitFor(() => screen.getByTestId('btn-submit-enrollment-decision'))
    fireEvent.click(screen.getByTestId('btn-submit-enrollment-decision'))

    await waitFor(() => {
      expect(saApi.approveEnrollment).toHaveBeenCalledWith('SKSA-0003', '')
      expect(screen.queryByTestId('enrollment-card-SKSA-0003')).not.toBeInTheDocument()
    })
  })

  it('rejects enrollment when reject selected', async () => {
    vi.mocked(saApi.rejectEnrollment).mockResolvedValue({ ok: true, message: 'Rejected' })

    render(<HRPortal />)
    await waitFor(() => screen.getByTestId('btn-review-SKSA-0003'))
    fireEvent.click(screen.getByTestId('btn-review-SKSA-0003'))
    await waitFor(() => screen.getByTestId('btn-reject-enrollment'))
    fireEvent.click(screen.getByTestId('btn-reject-enrollment'))
    fireEvent.click(screen.getByTestId('btn-submit-enrollment-decision'))

    await waitFor(() => {
      expect(saApi.rejectEnrollment).toHaveBeenCalledWith('SKSA-0003', '')
    })
  })

  it('switches to monthly overview tab and loads data', async () => {
    render(<HRPortal />)

    await waitFor(() => screen.getByTestId('tab-overview'))
    fireEvent.click(screen.getByTestId('tab-overview'))

    await waitFor(() => {
      expect(screen.getByTestId('overview-table')).toBeInTheDocument()
    })
    expect(screen.getByText('Tunde Adeola')).toBeInTheDocument()
    expect(screen.getByText(/76%/i)).toBeInTheDocument()
  })

  it('filters overview rows by search', async () => {
    vi.mocked(saApi.getHROverview).mockResolvedValue({
      ...mockHROverview,
      rows: [
        ...mockHROverview.rows,
        {
          ...mockHROverview.rows[0],
          assistant_id: 'SKSA-0002',
          assistant_name: 'Amaka Obi',
          assistant_email: 'amaka@sunking.com',
        },
      ],
    })

    render(<HRPortal />)
    fireEvent.click(screen.getByTestId('tab-overview'))
    await waitFor(() => screen.getByTestId('overview-search'))
    fireEvent.change(screen.getByTestId('overview-search'), { target: { value: 'Amaka' } })

    await waitFor(() => {
      expect(screen.queryByTestId('overview-row-SKSA-0001')).not.toBeInTheDocument()
      expect(screen.getByTestId('overview-row-SKSA-0002')).toBeInTheDocument()
    })
  })

  it('opens HR decision modal and submits VALIDATED', async () => {
    vi.mocked(saApi.submitHRDecision).mockResolvedValue({
      ok: true, hr_status: 'VALIDATED', message: 'Saved',
    })

    render(<HRPortal />)
    fireEvent.click(screen.getByTestId('tab-overview'))
    await waitFor(() => screen.getByTestId('btn-hr-decision-SKSA-0001'))
    fireEvent.click(screen.getByTestId('btn-hr-decision-SKSA-0001'))
    await waitFor(() => screen.getByTestId('hr-decision-modal'))
    fireEvent.click(screen.getByTestId('btn-submit-hr-decision'))

    await waitFor(() => {
      expect(saApi.submitHRDecision).toHaveBeenCalledWith(
        expect.objectContaining({
          assistant_id: 'SKSA-0001',
          decision: 'VALIDATED',
        })
      )
      expect(screen.queryByTestId('hr-decision-modal')).not.toBeInTheDocument()
    })
  })

  it('triggers CSV download on export click', async () => {
    vi.mocked(saApi.exportApproved).mockResolvedValue({
      ok: true,
      count: 1,
      filename: 'Approved_SA_2026_03.csv',
      csv: 'AssistantID,Name\nSKSA-0001,Tunde\n',
      message: '1 exported',
    })

    // Mock URL.createObjectURL
    global.URL.createObjectURL = vi.fn().mockReturnValue('blob:test')
    global.URL.revokeObjectURL = vi.fn()

    const clickSpy = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {})

    render(<HRPortal />)
    fireEvent.click(screen.getByTestId('tab-overview'))
    await waitFor(() => screen.getByTestId('btn-export'))
    fireEvent.click(screen.getByTestId('btn-export'))

    await waitFor(() => {
      expect(saApi.exportApproved).toHaveBeenCalled()
      expect(clickSpy).toHaveBeenCalled()
    })
  })
})
