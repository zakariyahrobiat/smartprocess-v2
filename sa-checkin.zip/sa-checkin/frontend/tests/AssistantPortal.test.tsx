/**
 * AssistantPortal tests — Vitest + React Testing Library
 * TDD: test what the user sees and does, not implementation.
 */
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { vi, describe, it, expect, beforeEach } from 'vitest'
import AssistantPortal from '../../src/components/shop-assistant/AssistantPortal'
import { saApi } from '../../src/api/saApi'
import type { AssistantDashboard, CheckinResponse } from '../../src/types/sa.types'

const mockEnrolledDashboard: AssistantDashboard = {
  profile: {
    assistant_id: 'SKSA-0001',
    assistant_name: 'Tunde Adeola',
    email: 'tunde@sunking.com',
    shop_id: 'SHOP-001',
    shop_area: 'Lagos Island',
    supervisor_email: 'sup@sunking.com',
    enrollment_status: 'ENROLLED',
    reference_photo_url: 'https://storage.test/x.jpg',
  },
  checked_in_today: false,
  last_checkin_time: null,
}

const mockUnenrolledDashboard: AssistantDashboard = {
  ...mockEnrolledDashboard,
  profile: { ...mockEnrolledDashboard.profile, enrollment_status: 'NONE', reference_photo_url: null },
}

const mockPendingDashboard: AssistantDashboard = {
  ...mockEnrolledDashboard,
  profile: { ...mockEnrolledDashboard.profile, enrollment_status: 'PENDING', reference_photo_url: null },
}

const mockCheckedInDashboard: AssistantDashboard = {
  ...mockEnrolledDashboard,
  checked_in_today: true,
}


describe('AssistantPortal — Enrollment Flow', () => {

  it('shows enrollment prompt for unenrolled assistant', async () => {
    vi.mocked(saApi.getDashboard).mockResolvedValue(mockUnenrolledDashboard)

    render(<AssistantPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('enroll-prompt')).toBeInTheDocument()
    })
    expect(screen.getByText(/Face Enrollment Required/i)).toBeInTheDocument()
    expect(screen.getByTestId('btn-start-enrollment')).toBeInTheDocument()
  })

  it('shows rejection message for rejected enrollment', async () => {
    const rejectedDashboard = {
      ...mockEnrolledDashboard,
      profile: { ...mockEnrolledDashboard.profile, enrollment_status: 'REJECTED' as const },
    }
    vi.mocked(saApi.getDashboard).mockResolvedValue(rejectedDashboard)

    render(<AssistantPortal />)

    await waitFor(() => {
      expect(screen.getByText(/Enrollment Rejected/i)).toBeInTheDocument()
    })
  })

  it('shows pending screen when enrollment is awaiting HR', async () => {
    vi.mocked(saApi.getDashboard).mockResolvedValue(mockPendingDashboard)

    render(<AssistantPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('enroll-pending')).toBeInTheDocument()
    })
    expect(screen.getByText(/Pending HR Approval/i)).toBeInTheDocument()
  })

  it('opens camera when start enrollment is clicked', async () => {
    vi.mocked(saApi.getDashboard).mockResolvedValue(mockUnenrolledDashboard)

    render(<AssistantPortal />)
    await waitFor(() => screen.getByTestId('btn-start-enrollment'))

    fireEvent.click(screen.getByTestId('btn-start-enrollment'))

    await waitFor(() => {
      expect(screen.getByTestId('camera-view')).toBeInTheDocument()
    })
    expect(navigator.mediaDevices.getUserMedia).toHaveBeenCalledWith(
      expect.objectContaining({ video: expect.any(Object) })
    )
  })

  it('shows selfie preview after capture', async () => {
    vi.mocked(saApi.getDashboard).mockResolvedValue(mockUnenrolledDashboard)

    // Mock canvas captureBase64
    HTMLCanvasElement.prototype.getContext = vi.fn().mockReturnValue({
      drawImage: vi.fn(),
    })
    HTMLCanvasElement.prototype.toDataURL = vi.fn().mockReturnValue('data:image/jpeg;base64,FAKEB64')

    render(<AssistantPortal />)
    await waitFor(() => screen.getByTestId('btn-start-enrollment'))
    fireEvent.click(screen.getByTestId('btn-start-enrollment'))
    await waitFor(() => screen.getByTestId('btn-capture'))
    fireEvent.click(screen.getByTestId('btn-capture'))

    await waitFor(() => {
      expect(screen.getByTestId('selfie-preview')).toBeInTheDocument()
    })
  })

  it('submits enrollment and transitions to pending', async () => {
    vi.mocked(saApi.getDashboard).mockResolvedValue(mockUnenrolledDashboard)
    vi.mocked(saApi.submitEnrollment).mockResolvedValue({
      ok: true,
      message: 'Submitted',
      status: 'PENDING',
    })

    HTMLCanvasElement.prototype.toDataURL = vi.fn().mockReturnValue('data:image/jpeg;base64,FAKEB64')

    render(<AssistantPortal />)
    await waitFor(() => screen.getByTestId('btn-start-enrollment'))
    fireEvent.click(screen.getByTestId('btn-start-enrollment'))
    await waitFor(() => screen.getByTestId('btn-capture'))
    fireEvent.click(screen.getByTestId('btn-capture'))
    await waitFor(() => screen.getByTestId('btn-confirm-selfie'))
    fireEvent.click(screen.getByTestId('btn-confirm-selfie'))

    await waitFor(() => {
      expect(screen.getByTestId('enroll-pending')).toBeInTheDocument()
    })
    expect(saApi.submitEnrollment).toHaveBeenCalled()
  })
})


describe('AssistantPortal — Check-In Flow', () => {

  beforeEach(() => {
    vi.mocked(saApi.getDashboard).mockResolvedValue(mockEnrolledDashboard)
    vi.mocked(saApi.getCheckinHistory).mockResolvedValue({ ok: true, month: 3, year: 2026, items: [] })
  })

  it('shows check-in button when enrolled and not yet checked in', async () => {
    render(<AssistantPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('btn-start-checkin')).toBeInTheDocument()
    })
  })

  it('shows checked-in message when already checked in today', async () => {
    vi.mocked(saApi.getDashboard).mockResolvedValue(mockCheckedInDashboard)

    render(<AssistantPortal />)

    await waitFor(() => {
      expect(screen.getByText(/checked in today/i)).toBeInTheDocument()
    })
    expect(screen.queryByTestId('btn-start-checkin')).not.toBeInTheDocument()
  })

  it('opens camera when check-in button clicked', async () => {
    render(<AssistantPortal />)
    await waitFor(() => screen.getByTestId('btn-start-checkin'))
    fireEvent.click(screen.getByTestId('btn-start-checkin'))

    await waitFor(() => {
      expect(screen.getByTestId('camera-view')).toBeInTheDocument()
    })
  })

  it('shows success result after successful check-in', async () => {
    const mockResult: CheckinResponse = {
      success: true,
      within_radius: true,
      face_match_score: 91,
      face_match_status: 'Match',
      checkin_method: 'FACE+GPS',
      message: 'Check-in recorded for Test Shop.',
      can_request_override: false,
      enrollment_required: false,
      enrollment_status: null,
    }
    vi.mocked(saApi.submitCheckin).mockResolvedValue(mockResult)
    HTMLCanvasElement.prototype.toDataURL = vi.fn().mockReturnValue('data:image/jpeg;base64,FAKEB64')

    render(<AssistantPortal />)
    await waitFor(() => screen.getByTestId('btn-start-checkin'))
    fireEvent.click(screen.getByTestId('btn-start-checkin'))
    await waitFor(() => screen.getByTestId('btn-capture'))
    fireEvent.click(screen.getByTestId('btn-capture'))
    await waitFor(() => screen.getByTestId('btn-confirm-selfie'))
    fireEvent.click(screen.getByTestId('btn-confirm-selfie'))

    await waitFor(() => {
      expect(screen.getByTestId('checkin-result')).toBeInTheDocument()
    })
    expect(screen.getByText(/Check-in recorded/i)).toBeInTheDocument()
    expect(screen.getByText(/91%/i)).toBeInTheDocument()
  })

  it('shows override button when face match fails', async () => {
    const failResult: CheckinResponse = {
      success: false,
      within_radius: true,
      face_match_score: 55,
      face_match_status: 'No Match',
      checkin_method: null,
      message: 'Face did not match (55%, minimum 80%).',
      can_request_override: true,
      enrollment_required: false,
      enrollment_status: null,
    }
    vi.mocked(saApi.submitCheckin).mockResolvedValue(failResult)
    HTMLCanvasElement.prototype.toDataURL = vi.fn().mockReturnValue('data:image/jpeg;base64,FAKEB64')

    render(<AssistantPortal />)
    await waitFor(() => screen.getByTestId('btn-start-checkin'))
    fireEvent.click(screen.getByTestId('btn-start-checkin'))
    await waitFor(() => screen.getByTestId('btn-capture'))
    fireEvent.click(screen.getByTestId('btn-capture'))
    await waitFor(() => screen.getByTestId('btn-confirm-selfie'))
    fireEvent.click(screen.getByTestId('btn-confirm-selfie'))

    await waitFor(() => {
      expect(screen.getByTestId('btn-request-override')).toBeInTheDocument()
    })
    expect(screen.getByText(/55%/i)).toBeInTheDocument()
  })

  it('displays assistant name and shop area in header', async () => {
    render(<AssistantPortal />)

    await waitFor(() => {
      expect(screen.getByText('Tunde Adeola')).toBeInTheDocument()
      expect(screen.getByText(/Lagos Island/i)).toBeInTheDocument()
    })
  })

  it('renders check-in history items', async () => {
    vi.mocked(saApi.getCheckinHistory).mockResolvedValue({
      ok: true, month: 3, year: 2026,
      items: [{
        timestamp_iso: '2026-03-10T08:00:00',
        assistant_id: 'SKSA-0001',
        distance_m: '45',
        within_radius: true,
        comment: '',
        face_match_score: '91',
        checkin_method: 'FACE+GPS',
      }],
    })

    render(<AssistantPortal />)

    await waitFor(() => {
      expect(screen.getByTestId('checkin-history')).toBeInTheDocument()
      expect(screen.getByText(/🔒 Face \+ GPS/i)).toBeInTheDocument()
    })
  })
})
