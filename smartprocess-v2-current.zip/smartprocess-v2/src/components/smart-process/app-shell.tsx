"use client"

import { useState } from "react"
import { TopBar } from "./top-bar"
import { SidebarNav, type AppView } from "./sidebar-nav"
import { MakerView } from "./maker-view"
import { SubmissionsList } from "./submissions-list"
import { CheckerView } from "./checker-view"
import { InverterDashboard } from "@/components/inverter-dashboard/inverter-dashboard"
import { mockSubmissions } from "@/lib/store"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useAuth } from "@/context/auth-provider"

// ── SA portals ────────────────────────────────────────────────────────────────
import AssistantPortal from "@/components/shop-assistant/AssistantPortal"
import SupervisorPortal from "@/components/shop-assistant/SupervisorPortal"
import HRPortal from "@/components/shop-assistant/HRPortal"

// ── Permission guard ──────────────────────────────────────────────────────────
function PermissionGuard({
  permission,
  children,
}: {
  permission: string
  children: React.ReactNode
}) {
  const { can } = useAuth()
  if (!can(permission as any)) {
    return (
      <div className="flex flex-col items-center justify-center h-96 gap-3 text-muted-foreground">
        <div className="text-4xl">🔒</div>
        <div className="text-sm font-medium">You don't have access to this module.</div>
        <div className="text-xs">Contact your administrator to request access.</div>
      </div>
    )
  }
  return <>{children}</>
}

export function AppShell() {
  const [currentView, setCurrentView] = useState<AppView>("new-request")
  const [mobileOpen, setMobileOpen] = useState(false)

  const pendingCount = mockSubmissions.filter(
    (s) => s.status === "pending" || s.status === "needs-info"
  ).length

  // SA views use full-width layout (no max-w constraint on portal canvases)
  const isSAView = currentView === "sa-checkin" ||
                   currentView === "sa-supervisor" ||
                   currentView === "sa-hr"

  const isInverterView = currentView === "inverter-dashboard"

  const maxWidth = isInverterView ? "max-w-7xl"
                 : isSAView      ? "max-w-5xl"
                 :                 "max-w-5xl"

  return (
    <div className="flex h-dvh flex-col bg-background">
      <TopBar onToggleSidebar={() => setMobileOpen(true)} />

      <div className="flex flex-1 overflow-hidden">
        <SidebarNav
          currentView={currentView}
          onNavigate={setCurrentView}
          pendingCount={pendingCount}
          mobileOpen={mobileOpen}
          onMobileClose={() => setMobileOpen(false)}
        />

        <main className="flex-1 overflow-y-auto">
          <div className={`mx-auto p-4 lg:p-8 ${maxWidth}`}>

            {/* ── Core views ── */}
            {currentView === "new-request" && <MakerView />}
            {currentView === "my-submissions" && (
              <SubmissionsList
                title="My Submissions"
                description="Track the status of all your submitted requests."
              />
            )}
            {currentView === "pending-actions" && <CheckerView />}
            {currentView === "history" && (
              <SubmissionsList
                title="History"
                description="Browse completed and archived submissions."
                filter="approved"
              />
            )}

            {/* ── Projects ── */}
            {currentView === "inverter-dashboard" && <InverterDashboard />}

            {/* ── Shop Assistant ── */}
            {currentView === "sa-checkin" && (
              <PermissionGuard permission="sa:checkin">
                <AssistantPortal />
              </PermissionGuard>
            )}
            {currentView === "sa-supervisor" && (
              <PermissionGuard permission="sa:supervisor">
                <SupervisorPortal />
              </PermissionGuard>
            )}
            {currentView === "sa-hr" && (
              <PermissionGuard permission="sa:hr">
                <HRPortal />
              </PermissionGuard>
            )}

          </div>
        </main>
      </div>
    </div>
  )
}
